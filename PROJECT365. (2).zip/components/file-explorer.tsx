'use client'

import React from 'react'
import { JSX } from 'react/jsx-runtime'

import { useAppContext } from '@/app/app-context'
import { ChevronRight, ChevronDown, Folder, FolderOpen, FileText, Code2, FileJson, FileCode, Trash2, Plus, AlertTriangle, Search, Copy, Edit2, ExpandIcon as ExpandAllIcon, ReplaceAllIcon as CollapseAllIcon, Info, X, Keyboard } from 'lucide-react'
import { useState, useMemo, useCallback } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { FileContextMenu } from './file-context-menu'
import { useKeyboardShortcuts, KEYBOARD_SHORTCUT_REFERENCE } from '@/hooks/use-keyboard-shortcuts'

interface FileNode {
  id: string
  name: string
  type: 'file' | 'folder'
  expanded?: boolean
  children?: FileNode[]
  content?: string
}

// Get appropriate icon based on file extension
function getFileIcon(fileName: string) {
  const ext = fileName.split('.').pop()?.toLowerCase()

  const iconMap: { [key: string]: JSX.Element } = {
    ts: <Code2 size={16} className="text-blue-400 flex-shrink-0" />,
    tsx: <Code2 size={16} className="text-blue-400 flex-shrink-0" />,
    js: <FileCode size={16} className="text-yellow-400 flex-shrink-0" />,
    jsx: <FileCode size={16} className="text-yellow-400 flex-shrink-0" />,
    json: <FileJson size={16} className="text-orange-400 flex-shrink-0" />,
    css: <FileCode size={16} className="text-purple-400 flex-shrink-0" />,
    scss: <FileCode size={16} className="text-purple-400 flex-shrink-0" />,
    html: <Code2 size={16} className="text-red-400 flex-shrink-0" />,
    py: <Code2 size={16} className="text-cyan-400 flex-shrink-0" />,
    java: <Code2 size={16} className="text-orange-500 flex-shrink-0" />,
    go: <Code2 size={16} className="text-cyan-500 flex-shrink-0" />,
    md: <FileText size={16} className="text-zinc-300 flex-shrink-0" />,
    txt: <FileText size={16} className="text-zinc-300 flex-shrink-0" />,
  }

  return iconMap[ext!] || <FileText size={16} className="text-zinc-400 flex-shrink-0" />
}

interface FileNodeProps {
  node: FileNode
  level: number
}

function FileNode({ node, level, searchQuery, onRename }: FileNodeProps & { searchQuery: string; onRename: (id: string, newName: string) => void }) {
  const {
    selectedFileId,
    selectFile,
    toggleFolder,
    deleteFile,
    addFile,
  } = useAppContext()
  const isFile = node.type === 'file'
  const isActive = selectedFileId === node.id
  const [showActions, setShowActions] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [isRenaming, setIsRenaming] = useState(false)
  const [newName, setNewName] = useState(node.name)
  const [showStats, setShowStats] = useState(false)
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragOver, setDragOver] = useState(false)

  // Check if this node or its children match search query
  const matchesSearch = useMemo(() => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return node.name.toLowerCase().includes(query)
  }, [node.name, searchQuery])

  const countItems = (n: FileNode): number => {
    if (n.type === 'file') return 1
    return (n.children?.reduce((sum, child) => sum + countItems(child), 0) || 0) + 1
  }

  const getFileSize = (): string => {
    if (!node.content) return '0 B'
    const bytes = new Blob([node.content]).size
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  const handleClick = () => {
    if (isFile) {
      selectFile(node.id)
    } else {
      toggleFolder(node.id)
    }
  }

  const handleAddFile = (e: React.MouseEvent) => {
    e.stopPropagation()
    const fileName = prompt('Enter file name:')
    if (fileName) {
      addFile(node.id, fileName, '// New file')
    }
  }

  const handleAddFolder = (e: React.MouseEvent) => {
    e.stopPropagation()
    const folderName = prompt('Enter folder name:')
    if (folderName) {
      addFile(node.id, folderName)
    }
  }

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    setShowDeleteDialog(true)
  }

  const handleConfirmDelete = () => {
    deleteFile(node.id)
    setShowDeleteDialog(false)
  }

  const handleRenameClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsRenaming(true)
  }

  const handleRenameSubmit = () => {
    if (newName && newName !== node.name) {
      onRename(node.id, newName)
    }
    setIsRenaming(false)
  }

  const handleCopyPath = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation()
    const fullPath = `${node.name}`
    navigator.clipboard.writeText(fullPath)
  }

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setContextMenu({ x: e.clientX, y: e.clientY })
    selectFile(node.id)
  }

  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation()
    setIsDragging(true)
    e.dataTransfer.effectAllowed = 'move'
    e.dataTransfer.setData('application/json', JSON.stringify({ id: node.id, name: node.name, type: node.type }))
  }

  const handleDragEnd = () => {
    setIsDragging(false)
    setDragOver(false)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (!isFile) {
      setDragOver(true)
      e.dataTransfer.dropEffect = 'move'
    }
  }

  const handleDragLeave = () => {
    setDragOver(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragOver(false)

    if (isFile) return

    try {
      const draggedData = JSON.parse(e.dataTransfer.getData('application/json'))
      // In a real app, you would handle file moving here
      console.log('[v0] Dropped', draggedData.name, 'into', node.name)
    } catch (error) {
      console.log('[v0] Drag-drop error:', error)
    }
  }

  const paddingLeft = level * 12

  if (!matchesSearch) return null

  return (
    <div>
      {/* Main Row */}
      {isRenaming ? (
        <div
          className="flex items-center gap-2 px-2 py-1"
          style={{ paddingLeft: `${paddingLeft}px` }}
        >
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onBlur={handleRenameSubmit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleRenameSubmit()
              if (e.key === 'Escape') setIsRenaming(false)
            }}
            className="flex-1 bg-zinc-800 text-zinc-100 px-2 py-0.5 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
            autoFocus
          />
        </div>
      ) : (
        <div
          className={`flex items-center gap-1 px-2 py-1 cursor-pointer transition-all group relative ${
            isActive
              ? 'bg-blue-500/20 text-blue-400'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
          } ${isDragging ? 'opacity-50' : ''} ${dragOver && !isFile ? 'bg-green-500/10 border-l-2 border-green-500' : ''}`}
          style={{ paddingLeft: `${paddingLeft}px` }}
          onClick={handleClick}
          onContextMenu={handleContextMenu}
          onMouseEnter={() => setShowActions(true)}
          onMouseLeave={() => setShowActions(false)}
          draggable={true}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {/* Vertical guide line */}
          {level > 0 && (
            <div className="absolute left-4 top-0 bottom-0 border-l border-zinc-800 opacity-20" />
          )}

          {/* Chevron for folders */}
          {!isFile && (
            <div className="w-4 flex-shrink-0 flex items-center justify-center">
              {node.expanded ? (
                <ChevronDown size={14} className="text-zinc-500" />
              ) : (
                <ChevronRight size={14} className="text-zinc-500" />
              )}
            </div>
          )}

          {/* Icon */}
          <div className="w-4 flex-shrink-0 flex items-center justify-center">
            {isFile ? (
              getFileIcon(node.name)
            ) : node.expanded ? (
              <FolderOpen size={16} className="text-blue-400" />
            ) : (
              <Folder size={16} className="text-blue-400" />
            )}
          </div>

          {/* File/Folder Name */}
          <span className="text-xs font-medium truncate flex-1">{node.name}</span>

          {/* Action Buttons */}
          {showActions && (
            <div className="flex gap-0.5 flex-shrink-0">
              {!isFile && (
                <button
                  onClick={handleAddFile}
                  className="p-0.5 hover:bg-zinc-700 rounded opacity-75 hover:opacity-100 transition-all"
                  title="Add file"
                >
                  <Plus size={12} />
                </button>
              )}
              {!isFile && (
                <button
                  onClick={handleAddFolder}
                  className="p-0.5 hover:bg-zinc-700 rounded opacity-75 hover:opacity-100 transition-all"
                  title="Add folder"
                >
                  <Folder size={12} />
                </button>
              )}
              <button
                onClick={handleRenameClick}
                className="p-0.5 hover:bg-zinc-700 rounded opacity-75 hover:opacity-100 transition-all"
                title="Rename"
              >
                <Edit2 size={12} />
              </button>
              {isFile && (
                <button
                  onClick={handleCopyPath}
                  className="p-0.5 hover:bg-zinc-700 rounded opacity-75 hover:opacity-100 transition-all"
                  title="Copy path"
                >
                  <Copy size={12} />
                </button>
              )}
              {isFile && (
                <button
                  onClick={() => setShowStats(!showStats)}
                  className="p-0.5 hover:bg-zinc-700 rounded opacity-75 hover:opacity-100 transition-all"
                  title="File info"
                >
                  <Info size={12} />
                </button>
              )}
              <button
                onClick={handleDeleteClick}
                className="p-0.5 hover:bg-red-900/30 hover:text-red-400 rounded opacity-75 hover:opacity-100 transition-all flex-shrink-0"
                title={isFile ? 'Delete file' : 'Delete folder'}
              >
                <Trash2 size={12} />
              </button>
            </div>
          )}
        </div>
      )}

      {/* File Stats Popover */}
      {showStats && isFile && (
        <div className="ml-4 mt-1 p-2 bg-zinc-900/50 border border-zinc-800 rounded text-xs text-zinc-400 space-y-1">
          <div className="flex justify-between">
            <span>Size:</span>
            <span className="text-zinc-200">{getFileSize()}</span>
          </div>
          <div className="flex justify-between">
            <span>Lines:</span>
            <span className="text-zinc-200">{(node.content?.split('\n') || []).length}</span>
          </div>
          <div className="flex justify-between">
            <span>Type:</span>
            <span className="text-zinc-200">{node.name.split('.').pop()?.toUpperCase() || 'N/A'}</span>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="border-zinc-800 bg-zinc-950">
          <DialogHeader>
            <div className="flex items-center gap-3">
              <AlertTriangle size={20} className="text-red-400" />
              <DialogTitle className="text-zinc-100">Delete {node.type === 'file' ? 'File' : 'Folder'}?</DialogTitle>
            </div>
            <DialogDescription className="text-zinc-400">
              {isFile ? (
                <>This action will permanently delete <span className="font-mono text-zinc-300">{node.name}</span>.</>
              ) : (
                <>
                  This will delete <span className="font-mono text-zinc-300">{node.name}</span> and all {countItems(node) - 1} item{countItems(node) - 1 !== 1 ? 's' : ''} inside it.
                </>
              )}
            </DialogDescription>
            <p className="mt-2 text-xs text-zinc-500">This action cannot be undone.</p>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setShowDeleteDialog(false)}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-900"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Delete {node.type === 'file' ? 'File' : 'Folder'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Context Menu */}
      <FileContextMenu
        position={contextMenu}
        isFile={isFile}
        onRename={handleRenameClick}
        onDelete={handleDeleteClick}
        onAddFile={!isFile ? handleAddFile : undefined}
        onAddFolder={!isFile ? handleAddFolder : undefined}
        onCopy={isFile ? handleCopyPath : undefined}
        onClose={() => setContextMenu(null)}
      />

      {/* Nested children */}
      {!isFile && node.expanded && node.children && (
        <div>
          {node.children.map((child) => (
            <FileNode key={child.id} node={child} level={level + 1} searchQuery={searchQuery} onRename={onRename} />
          ))}
        </div>
      )}
    </div>
  )
}

export function FileExplorer() {
  const { files, setFiles, selectedFileId, selectFile, addFile, deleteFile } = useAppContext()
  const [searchQuery, setSearchQuery] = useState('')
  const [expandedAll, setExpandedAll] = useState(false)
  const [showShortcuts, setShowShortcuts] = useState(false)
  const searchInputRef = React.useRef<HTMLInputElement>(null)

  const countTotalFiles = (nodes: FileNode[]): number => {
    return nodes.reduce((sum, node) => {
      let count = node.type === 'file' ? 1 : 0
      if (node.children) count += countTotalFiles(node.children)
      return sum + count
    }, 0)
  }

  const countTotalFolders = (nodes: FileNode[]): number => {
    return nodes.reduce((sum, node) => {
      let count = node.type === 'folder' ? 1 : 0
      if (node.children) count += countTotalFolders(node.children)
      return sum + count
    }, 0)
  }

  const expandAllFolders = (nodes: FileNode[]): FileNode[] => {
    return nodes.map((node) => ({
      ...node,
      expanded: node.type === 'folder',
      children: node.children ? expandAllFolders(node.children) : node.children,
    }))
  }

  const collapseAllFolders = (nodes: FileNode[]): FileNode[] => {
    return nodes.map((node) => ({
      ...node,
      expanded: false,
      children: node.children ? collapseAllFolders(node.children) : node.children,
    }))
  }

  const renameFile = (nodeId: string, newName: string, nodes = files): FileNode[] => {
    return nodes.map((node) => {
      if (node.id === nodeId) {
        return { ...node, name: newName }
      }
      if (node.children) {
        return { ...node, children: renameFile(nodeId, newName, node.children) }
      }
      return node
    })
  }

  const handleExpandAll = () => {
    setFiles(expandAllFolders(files))
    setExpandedAll(true)
  }

  const handleCollapseAll = () => {
    setFiles(collapseAllFolders(files))
    setExpandedAll(false)
  }

  const handleRename = (nodeId: string, newName: string) => {
    setFiles(renameFile(nodeId, newName))
  }

  const handleNewFile = useCallback(() => {
    if (selectedFileId) {
      const selectedNode = files.find((f) => f.id === selectedFileId)
      if (selectedNode?.type === 'folder') {
        addFile(selectedFileId, 'new-file.txt', '')
      }
    }
  }, [selectedFileId, files, addFile])

  const handleNewFolder = useCallback(() => {
    if (selectedFileId) {
      const selectedNode = files.find((f) => f.id === selectedFileId)
      if (selectedNode?.type === 'folder') {
        addFile(selectedFileId, 'new-folder')
      }
    }
  }, [selectedFileId, files, addFile])

  const handleDeleteSelected = useCallback(() => {
    if (selectedFileId) {
      deleteFile(selectedFileId)
    }
  }, [selectedFileId, deleteFile])

  const handleSearch = useCallback(() => {
    searchInputRef.current?.focus()
  }, [])

  // Set up keyboard shortcuts
  useKeyboardShortcuts({
    newFile: handleNewFile,
    newFolder: handleNewFolder,
    delete: handleDeleteSelected,
    expandAll: handleExpandAll,
    collapseAll: handleCollapseAll,
    search: handleSearch,
  })

  if (files.length === 0) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-zinc-800">
          <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-widest">
            Explorer
          </h3>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xs text-zinc-500 px-4 text-center">
            Import files or folders to get started
          </p>
        </div>
      </div>
    )
  }

  const totalFiles = countTotalFiles(files)
  const totalFolders = countTotalFolders(files)

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-3 border-b border-zinc-800 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-widest">
            Explorer
          </h3>
          <div className="flex items-center gap-2">
            <span className="text-xs text-zinc-500">
              {totalFiles} file{totalFiles !== 1 ? 's' : ''}, {totalFolders} folder{totalFolders !== 1 ? 's' : ''}
            </span>
            <button
              onClick={() => setShowShortcuts(true)}
              className="p-1 hover:bg-zinc-800 rounded transition-colors"
              title="Keyboard shortcuts"
              aria-label="Show keyboard shortcuts"
            >
              <Keyboard size={14} className="text-zinc-500 hover:text-zinc-300" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500" />
          <Input
            ref={searchInputRef}
            placeholder="Search files... (Ctrl+F)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-6 h-7 text-xs bg-zinc-900 border-zinc-700 text-zinc-200 placeholder-zinc-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 hover:bg-zinc-700 rounded p-0.5"
              aria-label="Clear search"
            >
              <X size={12} className="text-zinc-400" />
            </button>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-1">
          <Button
            size="sm"
            variant="outline"
            onClick={handleExpandAll}
            className="h-6 text-xs border-zinc-700 hover:bg-zinc-900 flex-1 bg-transparent"
            title="Expand all folders"
          >
            <ExpandAllIcon size={12} />
            Expand
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleCollapseAll}
            className="h-6 text-xs border-zinc-700 hover:bg-zinc-900 flex-1 bg-transparent"
            title="Collapse all folders"
          >
            <CollapseAllIcon size={12} />
            Collapse
          </Button>
        </div>
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-y-auto">
        {files.map((file) => (
          <FileNode key={file.id} node={file} level={0} searchQuery={searchQuery} onRename={handleRename} />
        ))}
      </div>

      {/* Keyboard Shortcuts Modal */}
      <Dialog open={showShortcuts} onOpenChange={setShowShortcuts}>
        <DialogContent className="border-zinc-800 bg-zinc-950 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-zinc-100 flex items-center gap-2">
              <Keyboard size={18} />
              Keyboard Shortcuts
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            {Object.entries(KEYBOARD_SHORTCUT_REFERENCE).map(([key, { keys, description }]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-zinc-400">{description}</span>
                <div className="flex gap-1">
                  {keys.map((k, i) => (
                    <React.Fragment key={k}>
                      <kbd className="px-2 py-1 bg-zinc-800 border border-zinc-700 rounded text-xs font-mono text-zinc-300">
                        {k}
                      </kbd>
                      {i < keys.length - 1 && <span className="text-zinc-600">+</span>}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button onClick={() => setShowShortcuts(false)} className="bg-blue-600 hover:bg-blue-700">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
