'use client'

import React, { useMemo, useState } from 'react'
import { Copy, Check, Download } from 'lucide-react'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { JSX } from 'react' // Import JSX to fix the undeclared variable error

interface CodeViewerProps {
  code: string
  fileName: string
  language?: string
}

const languageMap: Record<string, string> = {
  '.ts': 'typescript',
  '.tsx': 'tsx',
  '.js': 'javascript',
  '.jsx': 'jsx',
  '.py': 'python',
  '.java': 'java',
  '.cpp': 'cpp',
  '.c': 'c',
  '.go': 'go',
  '.rb': 'ruby',
  '.php': 'php',
  '.json': 'json',
  '.html': 'html',
  '.css': 'css',
  '.md': 'markdown',
  '.sql': 'sql',
}

function getLanguageFromFileName(fileName: string): string {
  const ext = fileName.substring(fileName.lastIndexOf('.')).toLowerCase()
  return languageMap[ext] || 'plaintext'
}

function highlightCode(code: string, language: string): JSX.Element[] {
  const lines = code.split('\n')
  
  return lines.map((line, idx) => {
    let highlightedLine = line

    // Simple syntax highlighting patterns
    if (language === 'typescript' || language === 'javascript' || language === 'jsx' || language === 'tsx') {
      // Keywords
      highlightedLine = highlightedLine.replace(
        /\b(const|let|var|function|async|await|return|if|else|for|while|switch|case|default|try|catch|finally|throw|import|export|from|as|class|extends|interface|type|enum|namespace|module|public|private|protected|static|readonly)\b/g,
        '<span class="text-blue-400">$1</span>'
      )
      // Strings
      highlightedLine = highlightedLine.replace(/(['"`])(.*?)\1/g, '<span class="text-green-400">$&</span>')
      // Comments
      highlightedLine = highlightedLine.replace(/(\/\/.*?)$/g, '<span class="text-zinc-500">$1</span>')
      highlightedLine = highlightedLine.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="text-zinc-500">$1</span>')
      // Numbers
      highlightedLine = highlightedLine.replace(/\b(\d+)\b/g, '<span class="text-cyan-400">$1</span>')
    } else if (language === 'python') {
      highlightedLine = highlightedLine.replace(
        /\b(def|class|import|from|return|if|elif|else|for|while|try|except|finally|with|as|lambda|pass|break|continue)\b/g,
        '<span class="text-blue-400">$1</span>'
      )
      highlightedLine = highlightedLine.replace(/(['"`])(.*?)\1/g, '<span class="text-green-400">$&</span>')
      highlightedLine = highlightedLine.replace(/(#.*?)$/g, '<span class="text-zinc-500">$1</span>')
      highlightedLine = highlightedLine.replace(/\b(\d+)\b/g, '<span class="text-cyan-400">$1</span>')
    } else if (language === 'json') {
      highlightedLine = highlightedLine.replace(/(".*?")\s*:/g, '<span class="text-yellow-400">$1</span>:')
      highlightedLine = highlightedLine.replace(/:\s*(".*?")/g, ': <span class="text-green-400">$1</span>')
      highlightedLine = highlightedLine.replace(/:\s*(true|false|null)/g, ': <span class="text-cyan-400">$1</span>')
      highlightedLine = highlightedLine.replace(/:\s*(\d+)/g, ': <span class="text-cyan-400">$1</span>')
    } else if (language === 'sql') {
      highlightedLine = highlightedLine.replace(
        /\b(SELECT|FROM|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|ON|AND|OR|NOT|INSERT|UPDATE|DELETE|CREATE|DROP|TABLE|DATABASE|INDEX|VIEW|PRIMARY|KEY|FOREIGN|CONSTRAINT)\b/gi,
        '<span class="text-blue-400">$1</span>'
      )
      highlightedLine = highlightedLine.replace(/('.*?')/g, '<span class="text-green-400">$1</span>')
      highlightedLine = highlightedLine.replace(/(--.*?)$/g, '<span class="text-zinc-500">$1</span>')
    }

    return (
      <div key={idx} className="flex hover:bg-zinc-900/30 transition-colors group">
        <div className="w-12 flex-shrink-0 text-right pr-4 py-0 text-zinc-600 select-none font-mono text-xs leading-6 border-r border-zinc-800/50">
          {idx + 1}
        </div>
        <div
          className="flex-1 py-0 px-4 font-mono text-sm text-zinc-300 leading-6 whitespace-pre-wrap break-words overflow-x-auto"
          dangerouslySetInnerHTML={{ __html: highlightedLine || '&nbsp;' }}
        />
      </div>
    )
  })
}

export function CodeViewer({ code, fileName, language }: CodeViewerProps) {
  const [copied, setCopied] = useState(false)
  const detectedLanguage = language || getLanguageFromFileName(fileName)
  const lines = code.split('\n')
  const fileSize = new Blob([code]).size
  const charCount = code.length

  const highlightedLines = useMemo(
    () => highlightCode(code, detectedLanguage),
    [code, detectedLanguage]
  )

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const element = document.createElement('a')
    const file = new Blob([code], { type: 'text/plain' })
    element.href = URL.createObjectURL(file)
    element.download = fileName
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-black/30 to-black/60">
      {/* Header */}
      <div className="relative border-b border-zinc-800 bg-black/40">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-transparent pointer-events-none" />
        <div className="relative px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div>
              <p className="text-sm font-semibold text-zinc-100">{fileName}</p>
              <p className="text-xs text-zinc-500 mt-0.5">
                {lines.length} lines • {charCount} characters • {(fileSize / 1024).toFixed(2)} KB
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-zinc-900/50 text-zinc-300 text-xs">
              {detectedLanguage.toUpperCase()}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDownload}
              className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
              title="Download file"
            >
              <Download size={16} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900"
              title="Copy to clipboard"
            >
              {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
            </Button>
          </div>
        </div>
      </div>

      {/* Code */}
      <div className="flex-1 overflow-auto bg-black/60 font-mono text-sm">
        <div className="flex flex-col">{highlightedLines}</div>
      </div>
    </div>
  )
}
