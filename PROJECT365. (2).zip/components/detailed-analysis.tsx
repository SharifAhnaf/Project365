'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { Lightbulb, AlertCircle, CheckCircle, BookOpen, Zap } from 'lucide-react'

interface DetailedAnalysisProps {
  analysis: string
  isLoading: boolean
}

export function DetailedAnalysis({ analysis, isLoading }: DetailedAnalysisProps) {
  const renderMarkdownSection = (text: string) => {
    const sections = text.split(/(?=##|###|\d+\.\s|\*\*Lines)/)

    return sections.map((section, idx) => {
      if (!section.trim()) return null

      // Extract section title and content
      const titleMatch = section.match(/^#{1,3}\s+(.+?)\n/)
      const title = titleMatch ? titleMatch[1] : null
      const content = section.replace(/^#{1,3}\s+.+?\n/, '').trim()

      // Determine icon based on content
      const getIcon = (title: string | null) => {
        if (!title) return null
        if (title.includes('Overview')) return <BookOpen size={18} className="text-blue-400" />
        if (title.includes('Purpose')) return <Zap size={18} className="text-cyan-400" />
        if (title.includes('Line')) return <CheckCircle size={18} className="text-green-400" />
        if (title.includes('Concept')) return <Lightbulb size={18} className="text-yellow-400" />
        if (title.includes('Issue') || title.includes('Problem')) return <AlertCircle size={18} className="text-red-400" />
        if (title.includes('Improve')) return <Lightbulb size={18} className="text-purple-400" />
        return null
      }

      const icon = getIcon(title)

      return (
        <motion.div
          key={idx}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: idx * 0.05 }}
          className="mb-6 pb-6 border-b border-zinc-800/50 last:border-0"
        >
          {title && (
            <div className="flex items-center gap-3 mb-3">
              {icon && <div className="flex-shrink-0">{icon}</div>}
              <h3 className="text-sm font-semibold text-zinc-100">{title}</h3>
            </div>
          )}

          <div className="space-y-3 text-sm text-zinc-300 leading-relaxed">
            {renderContent(content)}
          </div>
        </motion.div>
      )
    })
  }

  const renderContent = (content: string) => {
    // Split by newlines and format
    const lines = content.split('\n')

    return lines.map((line, idx) => {
      if (!line.trim()) return null

      // Simple text rendering without dangerouslySetInnerHTML to prevent XSS
      return (
        <p key={idx} className="whitespace-pre-wrap">
          {line}
        </p>
      )
    })
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
          className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full"
        />
        <div className="text-center">
          <p className="text-zinc-300 text-sm font-medium mb-1">Deep Analysis In Progress</p>
          <p className="text-zinc-500 text-xs">Generating comprehensive code explanation...</p>
        </div>
      </div>
    )
  }

  if (!analysis) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center gap-3">
        <BookOpen size={24} className="text-zinc-600" />
        <div>
          <p className="text-zinc-400 text-sm font-medium">No Analysis Yet</p>
          <p className="text-zinc-500 text-xs">Click the wand icon to generate detailed analysis</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4 text-sm">
      <div className="space-y-4">{renderMarkdownSection(analysis)}</div>

      {/* Footer Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-8 pt-6 border-t border-zinc-800 flex gap-4 text-xs text-zinc-500"
      >
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>AI-Powered Analysis</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-400" />
          <span>Real-time Explanation</span>
        </div>
      </motion.div>
    </div>
  )
}
