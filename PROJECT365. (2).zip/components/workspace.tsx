'use client'

import React from 'react'

import { Wand2, Loader, AlertCircle } from 'lucide-react'
import { Button } from './ui/button'
import { useAppContext } from '@/app/app-context'
import { useEffect, useState } from 'react'
import { DetailedAnalysis } from './detailed-analysis'
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from './ui/resizable'
import { AnalysisLoadingOverlay } from './analysis-loading-overlay'

export function Workspace() {
  const { 
    selectedFile, 
    selectedFileId, 
    updateFileContent, 
    translation, 
    isLoadingTranslation, 
    generateTranslation, 
    setTranslation,
    lastError,
    clearError,
  } = useAppContext()
  
  const [isEditMode, setIsEditMode] = useState(false)
  const [editedCode, setEditedCode] = useState('')
  const [cacheHit, setCacheHit] = useState(false)
  const [quotaExceeded, setQuotaExceeded] = useState(false)
  const [rateLimited, setRateLimited] = useState(false)
  const [isChunked, setIsChunked] = useState(false)

  const code = selectedFile?.content || ''
  const fileName = selectedFile?.name || 'file'

  useEffect(() => {
    setEditedCode(code)
    setTranslation({
      content: 'Click the wand icon to analyze this file',
      fromCache: false,
    })
    setQuotaExceeded(false)
    setRateLimited(false)
  }, [selectedFileId, setTranslation])

  const handleSaveEdit = () => {
    updateFileContent(selectedFileId!, editedCode)
    setIsEditMode(false)
  }

  const handleAnalyze = async () => {
    clearError()
    setCacheHit(false)
    setIsChunked(false)
    
    const response = await generateTranslation(code, fileName)
    
    if (response?.quotaExceeded) {
      setQuotaExceeded(true)
      setRateLimited(false)
    } else if (response?.rateLimited) {
      setRateLimited(true)
      setQuotaExceeded(false)
    } else {
      setQuotaExceeded(false)
      setRateLimited(false)
    }
    
    if (response?.chunked) {
      setIsChunked(true)
      setTimeout(() => setIsChunked(false), 4000)
    }
    
    if (response?.fromCache) {
      setCacheHit(true)
      setTimeout(() => setCacheHit(false), 3000)
    }
  }

  if (!selectedFile || selectedFile.type === 'folder') {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-br from-black/30 to-black/60">
        <div className="text-center">
          <p className="text-zinc-400">Select a file to view and edit</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full">
      <AnalysisLoadingOverlay isLoading={isLoadingTranslation} />
      
      {/* Dual Panel Viewer */}
      <div className="flex flex-col h-full">
        {/* Header with Translation Modes and Analyze Button */}
        <div className="relative border-b border-zinc-700 bg-gradient-to-r from-zinc-900/80 via-slate-900/60 to-zinc-900/80 backdrop-blur-sm">
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/8 via-transparent to-blue-500/5 pointer-events-none" />
          <div className="flex flex-col gap-3 px-5 py-4 relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-sm font-semibold text-zinc-200">Synchronized Analysis</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleAnalyze}
                disabled={isLoadingTranslation || quotaExceeded}
                title={quotaExceeded ? "Groq API quota exceeded for today" : "Analyze this code with selected mode"}
                className={`relative px-3 py-2 rounded-lg font-medium text-sm transition-all duration-300 overflow-hidden ${
                  quotaExceeded
                    ? 'text-red-400 bg-red-500/5 hover:bg-red-500/10 cursor-not-allowed'
                    : isLoadingTranslation
                      ? 'text-cyan-300 bg-gradient-to-r from-cyan-500/25 to-cyan-500/10 shadow-[0_0_16px_rgba(34,211,238,0.4)]'
                      : 'text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 hover:shadow-[0_0_12px_rgba(34,211,238,0.2)]'
                } active:scale-95`}
              >
                <div className="flex items-center gap-2 relative z-10">
                  {isLoadingTranslation ? (
                    <>
                      <Loader size={16} className="animate-spin" />
                      <span className="hidden sm:inline text-xs">Analyzing...</span>
                    </>
                  ) : quotaExceeded ? (
                    <>
                      <AlertCircle size={16} />
                      <span className="hidden sm:inline text-xs">Quota Exceeded</span>
                    </>
                  ) : (
                    <>
                      <Wand2 size={16} />
                      <span className="hidden sm:inline text-xs">Analyze</span>
                    </>
                  )}
                </div>
                {isLoadingTranslation && (
                  <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-cyan-500/40 via-cyan-500/20 to-transparent animate-shimmer pointer-events-none" style={{
                    backgroundSize: '200% 100%',
                    animation: 'shimmer 2s infinite'
                  }} />
                )}
              </Button>
            </div>

          </div>
        </div>

        {/* Warnings Section */}
        {quotaExceeded && (
          <div className="bg-red-900/20 border-b border-red-700 px-4 py-3 flex items-start gap-3">
            <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <p className="text-red-400 font-medium mb-1">Groq API Quota Exceeded</p>
              <p className="text-red-300">Daily quota limit reached. Please try again tomorrow.</p>
            </div>
          </div>
        )}

        {rateLimited && (
          <div className="bg-orange-900/20 border-b border-orange-700 px-4 py-3 flex items-start gap-3">
            <AlertCircle size={16} className="text-orange-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <p className="text-orange-400 font-medium mb-1">Rate Limited</p>
              <p className="text-orange-300">Too many requests. Please wait a moment (max 5 analyses per minute) before analyzing another file.</p>
            </div>
          </div>
        )}

        {cacheHit && (
          <div className="bg-green-900/20 border-b border-green-700 px-4 py-3 flex items-start gap-3">
            <AlertCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <p className="text-green-400 font-medium">Using Cached Result</p>
              <p className="text-green-300">This analysis was loaded from cache - instant results!</p>
            </div>
          </div>
        )}

        {isChunked && (
          <div className="bg-blue-900/20 border-b border-blue-700 px-4 py-3 flex items-start gap-3">
            <AlertCircle size={16} className="text-blue-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <p className="text-blue-400 font-medium">Large File Processed in Chunks</p>
              <p className="text-blue-300">Code was split into sections for better analysis coverage of all lines.</p>
            </div>
          </div>
        )}

        {/* Dual Panel Layout */}
        <ResizablePanelGroup direction="horizontal" className="flex-1">
          {/* Left Panel: Code */}
          <ResizablePanel defaultSize={50} minSize={30}>
            <div className="h-full overflow-auto bg-gradient-to-b from-zinc-950 via-slate-900 to-zinc-950 border-r border-zinc-700 scrollbar-thin scrollbar-thumb-blue-500 scrollbar-track-zinc-900/50">
              <div className="min-h-full p-6">
                <div className="mb-6 flex items-center gap-3">
                  <div className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full">{fileName}</div>
                  <div className="flex-1 h-px bg-gradient-to-r from-cyan-500/50 to-transparent" />
                </div>

                <div className="space-y-0 font-mono text-sm leading-7">
                  {code.split('\n').map((line, idx) => {
                    const lineNumber = idx + 1
                    return (
                      <div key={lineNumber} className="flex group hover:bg-zinc-800/40 transition-colors duration-150 px-2 rounded">
                        <div className="w-12 flex-shrink-0 text-right pr-3 text-zinc-600 group-hover:text-zinc-500 select-none text-xs">
                          {lineNumber}
                        </div>
                        <div className="flex-1 text-zinc-300 break-words text-sm">
                          {line || '\u00A0'}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle withHandle className="bg-zinc-700" />

          {/* Right Panel: Detailed Analysis */}
          <ResizablePanel defaultSize={50} minSize={30}>
            <div className="h-full overflow-auto bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 scrollbar-thin scrollbar-thumb-cyan-500 scrollbar-track-slate-900/50">
              <div className="min-h-full p-6">
                <div className="mb-6 flex items-center gap-3">
                  <div className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full">Analysis</div>
                  <div className="flex-1 h-px bg-gradient-to-r from-cyan-500/50 to-transparent" />
                </div>
                <DetailedAnalysis analysis={translation.content} isLoading={isLoadingTranslation} />
              </div>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  )
}
