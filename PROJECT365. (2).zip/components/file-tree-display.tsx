'use client'

import React from 'react'
import { ChevronRight, ChevronDown, Folder, FolderOpen, FileText } from 'lucide-react'
import { getFileIcon } from '@/lib/file-utils'
import type { FileNode } from '@/lib/file-tree-builder'

interface FileTreeDisplayProps {
  nodes: FileNode[]
  selectedId: string | null
  onSelectFile: (id: string) => void
  onToggleFolder: (id: string) => void
  onDelete?: (id: string) => void
  onAddFile?: (parentId: string) => void
  showStats?: boolean
}

export function FileTreeDisplay({
  nodes,
  selectedId,
  onSelectFile,
  onToggleFolder,
  onDelete,
  onAddFile,
  showStats,
}: FileTreeDisplayProps) {
  if (nodes.length === 0) {
    return (
      <div className="p-4 text-center text-zinc-500 text-sm">
        <p>No files imported yet</p>
        <p className="text-xs mt-2">Use the import button to add files</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* File Tree */}
      <div className="flex-1 overflow-auto">
        {nodes.map((node) => (
          <FileNodeRenderer
            key={node.id}
            node={node}
            level={0}
            selectedId={selectedId}
            onSelectFile={onSelectFile}
            onToggleFolder={onToggleFolder}
            onDelete={onDelete}
            onAddFile={onAddFile}
          />
        ))}
      </div>

      {/* Stats Footer */}
      {showStats && nodes.length > 0 && (
        <div className="border-t border-zinc-800 bg-black/40 px-4 py-2 text-xs text-zinc-500">
          <div className="flex gap-4">
            <span>{nodes[0].children?.length || 0} items</span>
          </div>
        </div>
      )}
    </div>
  )
}

interface FileNodeRendererProps {
  node: FileNode
  level: number
  selectedId: string | null
  onSelectFile: (id: string) => void
  onToggleFolder: (id: string) => void
  onDelete?: (id: string) => void
  onAddFile?: (parentId: string) => void
}

function FileNodeRenderer({
  node,
  level,
  selectedId,
  onSelectFile,
  onToggleFolder,
  onDelete,
  onAddFile,
}: FileNodeRendererProps) {
  const isFile = node.type === 'file'
  const isExpanded = node.expanded !== false
  const isSelected = selectedId === node.id
  const paddingLeft = level * 12

  return (
    <div key={node.id}>
      {/* Node item */}
      <div
        className={`flex items-center gap-1 px-2 py-1 text-sm cursor-pointer group hover:bg-zinc-800/50 transition-colors ${
          isSelected ? 'bg-zinc-800 text-blue-400' : 'text-zinc-400'
        }`}
        style={{ paddingLeft: `${paddingLeft}px` }}
        onClick={() => {
          if (isFile) {
            onSelectFile(node.id)
          } else {
            onToggleFolder(node.id)
          }
        }}
      >
        {/* Expand/Collapse Chevron */}
        {!isFile && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              onToggleFolder(node.id)
            }}
            className="p-0 hover:bg-zinc-700/50 rounded transition-colors"
          >
            {isExpanded ? (
              <ChevronDown size={14} className="flex-shrink-0" />
            ) : (
              <ChevronRight size={14} className="flex-shrink-0" />
            )}
          </button>
        )}

        {/* Indent for files (no chevron) */}
        {isFile && <div className="w-3.5 flex-shrink-0" />}

        {/* File/Folder Icon */}
        {isFile ? (
          getFileIcon(node.name)
        ) : isExpanded ? (
          <FolderOpen size={14} className="text-blue-400 flex-shrink-0" />
        ) : (
          <Folder size={14} className="text-blue-400 flex-shrink-0" />
        )}

        {/* File/Folder Name */}
        <span className="truncate flex-1">{node.name}</span>

        {/* Actions */}
        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
          {!isFile && onAddFile && (
            <button
              onClick={(e) => {
                e.stopPropagation()
                onAddFile(node.id)
              }}
              className="p-1 hover:bg-zinc-700 rounded text-zinc-500 hover:text-zinc-300 transition-colors"
              title="Add file"
            >
              <FileText size={12} />
            </button>
          )}
          {onDelete && (
            <button
              onClick={(e) => {
                e.stopPropagation()
                onDelete(node.id)
              }}
              className="p-1 hover:bg-red-900/30 rounded text-zinc-500 hover:text-red-400 transition-colors"
              title="Delete"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Children */}
      {!isFile && isExpanded && node.children && node.children.length > 0 && (
        <div>
          {node.children.map((child) => (
            <FileNodeRenderer
              key={child.id}
              node={child}
              level={level + 1}
              selectedId={selectedId}
              onSelectFile={onSelectFile}
              onToggleFolder={onToggleFolder}
              onDelete={onDelete}
              onAddFile={onAddFile}
            />
          ))}
        </div>
      )}
    </div>
  )
}
