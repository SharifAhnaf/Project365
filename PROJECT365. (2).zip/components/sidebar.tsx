'use client'

import { DialogDescription } from "@/components/ui/dialog"

import React from 'react'
import { useState } from 'react'
import { Button } from './ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { Progress } from './ui/progress'
import { Upload } from 'lucide-react'
import { useAppContext } from '@/app/app-context'
import { extractArchive, isArchiveFile } from '@/lib/archive-utils'
import { FileExplorer } from './file-explorer'

export function Sidebar() {
  const { files, setFiles, addFile, buildFileTreeFromExtracted, selectFile } = useAppContext()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const handleImportClick = () => {
    setIsDialogOpen(true)
  }

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files
    if (!fileList || fileList.length === 0) return

    setUploadProgress(10)

    try {
      let filesProcessed = 0
      const totalFiles = fileList.length
      const uploadedFileIds: string[] = []

      for (const file of Array.from(fileList)) {
        // Check if it's an archive file
        if (isArchiveFile(file.name)) {
          setUploadProgress(10 + (filesProcessed / totalFiles) * 40)
          try {
            const extractedFiles = await extractArchive(file)
            
            if (extractedFiles.length > 0) {
              // Build file tree from extracted files
              const newTree = buildFileTreeFromExtracted(extractedFiles)
              setFiles(newTree)
              
              // Select first file automatically
              const firstFile = findFirstFile(newTree)
              if (firstFile) {
                selectFile(firstFile.id)
                uploadedFileIds.push(firstFile.id)
              }
            }
          } catch (error) {
            console.error('Error extracting archive:', error)
          }
        } else {
          // Regular file upload
          const reader = new FileReader()
          reader.onload = (event) => {
            const content = event.target?.result as string
            
            // Create root folder if needed
            if (files.length === 0) {
              const rootFolder = {
                id: 'root-' + Date.now(),
                name: 'Project',
                type: 'folder' as const,
                expanded: true,
                children: [],
              }
              setFiles([rootFolder])
              addFile(rootFolder.id, file.name, content)
              uploadedFileIds.push(file.name)
            } else {
              // Add to existing root
              addFile(files[0].id, file.name, content)
              uploadedFileIds.push(file.name)
            }
          }
          reader.readAsText(file)
        }

        filesProcessed++
        setUploadProgress(10 + (filesProcessed / totalFiles) * 80)
      }

      // Complete upload
      setTimeout(() => {
        setUploadProgress(100)
        setTimeout(() => {
          setIsDialogOpen(false)
          setUploadProgress(0)
        }, 500)
      }, 500)
    } catch (error) {
      console.error('Error uploading files:', error)
      setUploadProgress(0)
    }
  }

  const findFirstFile = (nodes: any[]): any | null => {
    for (const node of nodes) {
      if (node.type === 'file') return node
      if (node.children) {
        const found = findFirstFile(node.children)
        if (found) return found
      }
    }
    return null
  }

  return (
    <>
      <div className="flex flex-col h-full bg-gradient-to-b from-black to-black/60">
        {/* Import Button */}
        <div className="relative m-4 group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <Button
            onClick={handleImportClick}
            variant="outline"
            className="w-full relative overflow-hidden border-dashed border-zinc-600 hover:border-blue-500/50 hover:bg-zinc-900/50 gap-2 transition-all duration-300 bg-transparent text-xs"
          >
            <Upload size={14} />
            <span>Import Files</span>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-blue-500/10 to-blue-500/0 rounded pointer-events-none" />
          </Button>
        </div>

        {/* File Explorer */}
        <div className="flex-1 overflow-hidden">
          <FileExplorer />
        </div>
      </div>

      {/* Import Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md border-zinc-800 bg-zinc-950">
          <DialogHeader>
            <DialogTitle className="text-zinc-100">Import Repository</DialogTitle>
            <DialogDescription className="text-zinc-400">
              Drag and drop files or click to select files to import into your project
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Drag & Drop Zone */}
            <label className="border-2 border-dashed border-zinc-700 rounded-lg p-8 text-center hover:border-zinc-600 transition-colors cursor-pointer block">
              <Upload size={32} className="mx-auto text-zinc-600 mb-2" />
              <p className="text-sm text-zinc-400">Drag and drop your files here</p>
              <p className="text-xs text-zinc-500 mt-1">or click to select</p>
              <input
                type="file"
                multiple
                onChange={handleFileInput}
                className="hidden"
              />
            </label>

            {/* Progress */}
            {uploadProgress > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-400">Processing...</span>
                  <span className="text-zinc-500">{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
