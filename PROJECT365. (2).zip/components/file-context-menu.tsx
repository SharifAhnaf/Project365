'use client'

import React, { useState, useRef, useEffect } from 'react'
import { Copy, Trash2, Edit2, Plus, Folder, FileText, Download } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ContextMenuPosition {
  x: number
  y: number
}

interface ContextMenuProps {
  position: ContextMenuPosition | null
  isFile: boolean
  onRename: () => void
  onDelete: () => void
  onAddFile?: () => void
  onAddFolder?: () => void
  onCopy?: () => void
  onClose: () => void
}

export function FileContextMenu({
  position,
  isFile,
  onRename,
  onDelete,
  onAddFile,
  onAddFolder,
  onCopy,
  onClose,
}: ContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null)
  const [adjustedPosition, setAdjustedPosition] = useState(position)

  useEffect(() => {
    if (!position || !menuRef.current) return

    const rect = menuRef.current.getBoundingClientRect()
    let { x, y } = position

    // Adjust if menu goes off-screen
    if (x + rect.width > window.innerWidth) {
      x = window.innerWidth - rect.width - 8
    }
    if (y + rect.height > window.innerHeight) {
      y = window.innerHeight - rect.height - 8
    }

    setAdjustedPosition({ x, y })
  }, [position])

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose()
      }
    }

    if (position) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [position, onClose])

  if (!position || !adjustedPosition) return null

  return (
    <div
      ref={menuRef}
      className="fixed z-50 min-w-48 bg-zinc-900 border border-zinc-800 rounded-lg shadow-xl py-1"
      style={{
        left: `${adjustedPosition.x}px`,
        top: `${adjustedPosition.y}px`,
      }}
      onClick={onClose}
    >
      {/* Rename */}
      <button
        onClick={() => {
          onRename()
          onClose()
        }}
        className="w-full px-3 py-2 text-left text-sm text-zinc-300 hover:bg-zinc-800 hover:text-blue-400 flex items-center gap-2 transition-colors"
      >
        <Edit2 size={14} />
        <span>Rename</span>
      </button>

      {/* Copy Path */}
      {onCopy && (
        <button
          onClick={() => {
            onCopy()
            onClose()
          }}
          className="w-full px-3 py-2 text-left text-sm text-zinc-300 hover:bg-zinc-800 hover:text-blue-400 flex items-center gap-2 transition-colors"
        >
          <Copy size={14} />
          <span>Copy Path</span>
        </button>
      )}

      {/* Add File (only for folders) */}
      {!isFile && onAddFile && (
        <>
          <div className="h-px bg-zinc-800 my-1" />
          <button
            onClick={() => {
              onAddFile()
              onClose()
            }}
            className="w-full px-3 py-2 text-left text-sm text-zinc-300 hover:bg-zinc-800 hover:text-green-400 flex items-center gap-2 transition-colors"
          >
            <Plus size={14} />
            <span>New File</span>
          </button>
        </>
      )}

      {/* Add Folder (only for folders) */}
      {!isFile && onAddFolder && (
        <button
          onClick={() => {
            onAddFolder()
            onClose()
          }}
          className="w-full px-3 py-2 text-left text-sm text-zinc-300 hover:bg-zinc-800 hover:text-green-400 flex items-center gap-2 transition-colors"
        >
          <Folder size={14} />
          <span>New Folder</span>
        </button>
      )}

      {/* Divider */}
      <div className="h-px bg-zinc-800 my-1" />

      {/* Delete */}
      <button
        onClick={() => {
          onDelete()
          onClose()
        }}
        className="w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-red-900/20 flex items-center gap-2 transition-colors"
      >
        <Trash2 size={14} />
        <span>Delete</span>
      </button>
    </div>
  )
}
