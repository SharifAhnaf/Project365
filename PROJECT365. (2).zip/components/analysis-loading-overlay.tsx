'use client'

import React from 'react'
import { motion } from 'framer-motion'
import { Loader, Sparkles } from 'lucide-react'

interface AnalysisLoadingOverlayProps {
  isLoading: boolean
}

export function AnalysisLoadingOverlay({ isLoading }: AnalysisLoadingOverlayProps) {
  if (!isLoading) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.3, type: 'spring', stiffness: 300 }}
        className="relative bg-gradient-to-br from-zinc-900 via-slate-900 to-zinc-900 border border-cyan-500/30 rounded-xl p-8 shadow-2xl shadow-cyan-500/20 max-w-md w-full mx-4"
      >
        {/* Animated background glow */}
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-500/10 via-transparent to-blue-500/10 animate-pulse" />

        {/* Content */}
        <div className="relative flex flex-col items-center gap-6">
          {/* Animated loader icon */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full opacity-20 blur-lg" />
            <Loader size={48} className="text-cyan-400 relative" />
          </motion.div>

          {/* Loading text */}
          <div className="flex flex-col items-center gap-3">
            <h3 className="text-lg font-semibold text-zinc-100 text-center">
              Analyzing your code
            </h3>
            
            {/* Animated dots */}
            <motion.div className="flex gap-1">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{
                    duration: 1.4,
                    repeat: Infinity,
                    delay: i * 0.2,
                  }}
                  className="w-2 h-2 rounded-full bg-cyan-400"
                />
              ))}
            </motion.div>

            <p className="text-sm text-zinc-400 mt-2">
              AI is analyzing your code...
            </p>
          </div>

          {/* Progress indicators */}
          <div className="w-full space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles size={14} className="text-cyan-400" />
              <div className="flex-1 h-1 bg-zinc-800 rounded-full overflow-hidden">
                <motion.div
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="h-full w-1/3 bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                />
              </div>
            </div>
          </div>

          {/* Tip text */}
          <p className="text-xs text-zinc-500 text-center mt-4">
            This may take a few seconds depending on code complexity
          </p>
        </div>

        {/* Corner accents */}
        <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-cyan-500/50 rounded-tl-xl" />
        <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-cyan-500/50 rounded-br-xl" />
      </motion.div>
    </motion.div>
  )
}
