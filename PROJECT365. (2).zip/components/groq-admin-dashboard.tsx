'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AlertTriangle, CheckCircle, Clock, TrendingUp } from 'lucide-react'

interface HealthStatus {
  apiConfigured: boolean
  recentErrorCount: number
  quotaStatus: {
    minuteUsage: string
    hourUsage: string
    dailyUsage: string
    minuteRemaining: number
  }
  performanceMetrics: {
    totalRequests: number
    successRate: string
    averageResponseTime: string
  }
  status: 'healthy' | 'degraded' | 'critical'
}

interface UsageStats {
  totalRequests: number
  successCount: number
  errorCount: number
  rateLimitedCount: number
  successRate: string
  averageResponseTime: string
  recentMetrics: any[]
}

interface EndpointUsage {
  endpoint: string
  totalCalls: number
  successCount: number
  failureCount: number
  averageResponseTime: string
}

export function GroqAdminDashboard() {
  const [healthData, setHealthData] = useState<HealthStatus | null>(null)
  const [usageStats, setUsageStats] = useState<UsageStats | null>(null)
  const [endpointUsage, setEndpointUsage] = useState<EndpointUsage[]>([])
  const [recentErrors, setRecentErrors] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const fetchAdminData = async () => {
    try {
      setRefreshing(true)
      const [healthRes, statsRes, endpointsRes, errorsRes] = await Promise.all([
        fetch('/api/groq-admin?action=health'),
        fetch('/api/groq-admin?action=stats'),
        fetch('/api/groq-admin?action=endpoints'),
        fetch('/api/groq-admin?action=errors?limit=5'),
      ])

      const [health, stats, endpoints, errors] = await Promise.all([
        healthRes.json(),
        statsRes.json(),
        endpointsRes.json(),
        errorsRes.json(),
      ])

      setHealthData(health.data)
      setUsageStats(stats.data)
      setEndpointUsage(endpoints.data || [])
      setRecentErrors(errors.data || [])
    } catch (error) {
      console.error('Failed to fetch admin data:', error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    fetchAdminData()
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchAdminData, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleReset = async () => {
    if (confirm('Are you sure you want to reset all metrics and error logs?')) {
      try {
        await fetch('/api/groq-admin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'reset' }),
        })
        fetchAdminData()
      } catch (error) {
        console.error('Failed to reset metrics:', error)
      }
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case 'degraded':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
      case 'critical':
        return <AlertTriangle className="w-5 h-5 text-red-500" />
      default:
        return <Clock className="w-5 h-5 text-gray-500" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-gray-400">Loading Groq API dashboard...</p>
      </div>
    )
  }

  return (
    <div className="w-full space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Groq API Management</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={fetchAdminData}
            disabled={refreshing}
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
          <Button variant="destructive" onClick={handleReset}>
            Reset Metrics
          </Button>
        </div>
      </div>

      {/* Health Status Alert */}
      {healthData && (
        <Alert
          className={`border-2 ${
            healthData.status === 'critical'
              ? 'border-red-500 bg-red-50'
              : healthData.status === 'degraded'
                ? 'border-yellow-500 bg-yellow-50'
                : 'border-green-500 bg-green-50'
          }`}
        >
          <div className="flex items-center gap-3">
            {getStatusIcon(healthData.status)}
            <div>
              <h3 className="font-semibold capitalize">{healthData.status} Status</h3>
              <AlertDescription>
                API is {healthData.apiConfigured ? 'configured' : 'not configured'}. Recent errors:{' '}
                {healthData.recentErrorCount}
              </AlertDescription>
            </div>
          </div>
        </Alert>
      )}

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="quota">Quota</TabsTrigger>
          <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
          <TabsTrigger value="errors">Errors</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {usageStats && (
              <>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{usageStats.totalRequests}</div>
                    <p className="text-xs text-gray-500 mt-1">All-time requests</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{usageStats.successRate}%</div>
                    <p className="text-xs text-gray-500 mt-1">{usageStats.successCount} successful</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{usageStats.averageResponseTime}ms</div>
                    <p className="text-xs text-gray-500 mt-1">Average latency</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Errors/Rate Limits</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{usageStats.errorCount + usageStats.rateLimitedCount}</div>
                    <p className="text-xs text-gray-500 mt-1">
                      {usageStats.errorCount} errors, {usageStats.rateLimitedCount} rate limited
                    </p>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              {usageStats?.recentMetrics && usageStats.recentMetrics.length > 0 ? (
                <div className="space-y-2">
                  {usageStats.recentMetrics.map((metric, idx) => (
                    <div key={idx} className="flex justify-between text-sm border-b pb-2">
                      <div>
                        <p className="font-medium">{metric.endpoint}</p>
                        <p className="text-xs text-gray-500">
                          Mode: {metric.mode || 'N/A'} | Status: {metric.status}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-mono">{metric.responseTime}ms</p>
                        <p className="text-xs text-gray-500">{metric.tokensUsed} tokens</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No recent activity</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quota" className="space-y-4">
          {healthData && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Per Minute</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{healthData.quotaStatus.minuteRemaining}</div>
                    <p className="text-xs text-gray-500 mt-1">{healthData.quotaStatus.minuteUsage}</p>
                    <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{
                          width: `${(parseInt(healthData.quotaStatus.minuteUsage.split('/')[0]) / parseInt(healthData.quotaStatus.minuteUsage.split('/')[1])) * 100}%`,
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Per Hour</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">Available</div>
                    <p className="text-xs text-gray-500 mt-1">{healthData.quotaStatus.hourUsage}</p>
                    <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-green-500 h-2 rounded-full"
                        style={{
                          width: `${(parseInt(healthData.quotaStatus.hourUsage.split('/')[0]) / parseInt(healthData.quotaStatus.hourUsage.split('/')[1])) * 100}%`,
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Per Day</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">Available</div>
                    <p className="text-xs text-gray-500 mt-1">{healthData.quotaStatus.dailyUsage}</p>
                    <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-purple-500 h-2 rounded-full"
                        style={{
                          width: `${(parseInt(healthData.quotaStatus.dailyUsage.split('/')[0]) / parseInt(healthData.quotaStatus.dailyUsage.split('/')[1])) * 100}%`,
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Performance</CardTitle>
                  <CardDescription>Current API performance metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Requests:</span>
                    <span className="font-mono font-semibold">
                      {healthData.performanceMetrics.totalRequests}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Success Rate:</span>
                    <span className="font-mono font-semibold">
                      {healthData.performanceMetrics.successRate}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg Response Time:</span>
                    <span className="font-mono font-semibold">
                      {healthData.performanceMetrics.averageResponseTime}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="endpoints" className="space-y-4">
          {endpointUsage.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {endpointUsage.map((endpoint) => (
                <Card key={endpoint.endpoint}>
                  <CardHeader>
                    <CardTitle className="text-sm">{endpoint.endpoint}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Total Calls:</span>
                      <span className="font-mono font-semibold">{endpoint.totalCalls}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Success:</span>
                      <span className="font-mono font-semibold text-green-600">{endpoint.successCount}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Failed:</span>
                      <span className="font-mono font-semibold text-red-600">{endpoint.failureCount}</span>
                    </div>
                    <div className="flex justify-between text-sm border-t pt-2">
                      <span>Avg Response Time:</span>
                      <span className="font-mono font-semibold">{endpoint.averageResponseTime}ms</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-500">No endpoint usage data available</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="errors" className="space-y-4">
          {recentErrors.length > 0 ? (
            <div className="space-y-2">
              {recentErrors.map((error, idx) => (
                <Card key={idx}>
                  <CardContent className="pt-6">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-semibold text-sm">{error.endpoint}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(error.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm text-red-600">{error.error}</p>
                      {error.details && (
                        <details className="mt-2">
                          <summary className="text-xs cursor-pointer text-gray-500 hover:text-gray-700">
                            Details
                          </summary>
                          <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-auto max-h-32">
                            {JSON.stringify(error.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-gray-500">No recent errors</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
