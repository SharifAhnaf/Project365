'use client'

import React, { useState, useRef, useEffect } from 'react'
import { motion } from 'framer-motion'
import { ChevronRight, Code2, Sparkles } from 'lucide-react'

interface LogicCard {
  lineRange: string
  title: string
  description: string
  startLine: number
  endLine: number
}

interface DualPanelViewerProps {
  code: string
  fileName: string
  codeExplanation: string
  isLoading?: boolean
}

// Mock data mapping line numbers to explanations
const generateMockLogicCards = (explanation: string, totalLines: number): LogicCard[] => {
  if (!explanation) return []
  
  // Split explanation into logical chunks
  const chunks = explanation.split('\n\n').filter(chunk => chunk.trim())
  
  if (chunks.length === 0) return []

  const cardsPerChunk = Math.ceil(totalLines / chunks.length)
  
  return chunks.slice(0, 5).map((chunk, idx) => {
    const startLine = idx * cardsPerChunk + 1
    const endLine = Math.min((idx + 1) * cardsPerChunk, totalLines)
    const title = chunk.split('\n')[0].substring(0, 40) + '...'
    
    return {
      lineRange: `Lines ${startLine}-${endLine}`,
      title,
      description: chunk,
      startLine,
      endLine,
    }
  })
}

export function DualPanelViewer({ code, fileName, codeExplanation, isLoading }: DualPanelViewerProps) {
  const [activeLineRange, setActiveLineRange] = useState<{ start: number; end: number } | null>(null)
  const [hoveredLine, setHoveredLine] = useState<number | null>(null)
  const codePanel = useRef<HTMLDivElement>(null)
  const translationPanel = useRef<HTMLDivElement>(null)
  const activeCardRef = useRef<HTMLDivElement>(null)

  const lines = code.split('\n')
  const logicCards = generateMockLogicCards(codeExplanation, lines.length)

  // Auto-scroll active card into view
  useEffect(() => {
    if (activeCardRef.current && translationPanel.current) {
      activeCardRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
    }
  }, [activeLineRange])

  const handleLineClick = (lineNumber: number) => {
    setActiveLineRange({ start: lineNumber, end: lineNumber })
  }

  const handleCardClick = (card: LogicCard) => {
    setActiveLineRange({ start: card.startLine, end: card.endLine })
    // Scroll code panel to show the range
    if (codePanel.current) {
      const lineElement = codePanel.current.querySelector(`[data-line="${card.startLine}"]`)
      if (lineElement) {
        lineElement.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    }
  }

  return (
    <div className="h-full w-full flex overflow-hidden bg-zinc-950">
      {/* Left Panel: Source Code */}
      <div
        ref={codePanel}
        className="w-1/2 overflow-auto border-r border-zinc-700 bg-gradient-to-b from-zinc-950 via-slate-900 to-zinc-950 scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-zinc-900"
      >
        <style>{`
          div::-webkit-scrollbar { width: 8px; }
          div::-webkit-scrollbar-track { background: rgb(24, 24, 27); }
          div::-webkit-scrollbar-thumb { background: rgb(63, 63, 70); border-radius: 4px; }
          div::-webkit-scrollbar-thumb:hover { background: rgb(82, 82, 89); }
        `}</style>
        <div className="min-h-full p-6">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Code2 size={18} className="text-blue-400" />
              <h2 className="text-sm font-semibold text-zinc-200">{fileName}</h2>
            </div>
            <div className="flex-1 h-px bg-gradient-to-r from-blue-500/50 to-transparent" />
          </div>

          <div className="space-y-0 font-mono text-sm leading-7">
            {lines.map((line, idx) => {
              const lineNumber = idx + 1
              const isHovered = hoveredLine === lineNumber
              const isActive =
                activeLineRange &&
                lineNumber >= activeLineRange.start &&
                lineNumber <= activeLineRange.end

              return (
                <motion.div
                  key={lineNumber}
                  data-line={lineNumber}
                  onClick={() => handleLineClick(lineNumber)}
                  onMouseEnter={() => setHoveredLine(lineNumber)}
                  onMouseLeave={() => setHoveredLine(null)}
                  className={`flex group cursor-pointer transition-all duration-150 px-2 rounded ${
                    isActive
                      ? 'bg-blue-500/15 border-l-3 border-blue-400 shadow-[inset_0_0_15px_rgba(59,130,246,0.1)]'
                      : isHovered
                        ? 'bg-zinc-800/40'
                        : ''
                  }`}
                  whileHover={{ x: 2 }}
                >
                  {/* Line Number */}
                  <div className="w-12 flex-shrink-0 text-right pr-3 text-zinc-600 group-hover:text-zinc-500 select-none text-xs">
                    {lineNumber}
                  </div>

                  {/* Code */}
                  <div className="flex-1 text-zinc-300 break-words text-sm">
                    {line || '\u00A0'}
                  </div>
                </motion.div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Right Panel: English Logic Cards */}
      <div
        ref={translationPanel}
        className="w-1/2 overflow-auto bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-slate-900"
      >
        <style>{`
          div::-webkit-scrollbar { width: 8px; }
          div::-webkit-scrollbar-track { background: rgb(15, 23, 42); }
          div::-webkit-scrollbar-thumb { background: rgb(63, 63, 70); border-radius: 4px; }
          div::-webkit-scrollbar-thumb:hover { background: rgb(82, 82, 89); }
        `}</style>
        <div className="min-h-full p-6">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-cyan-400" />
              <h2 className="text-sm font-semibold text-zinc-200">Analysis</h2>
            </div>
            <div className="flex-1 h-px bg-gradient-to-r from-cyan-500/50 to-transparent" />
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-3" />
                <p className="text-zinc-400 text-sm">Analyzing code...</p>
              </div>
            </div>
          ) : logicCards.length > 0 ? (
            <div className="space-y-4">
              {logicCards.map((card, idx) => {
                const isActive =
                  activeLineRange &&
                  activeLineRange.start >= card.startLine &&
                  activeLineRange.end <= card.endLine

                return (
                  <motion.div
                    key={idx}
                    ref={isActive ? activeCardRef : null}
                    onClick={() => handleCardClick(card)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all duration-300 ${
                      isActive
                        ? 'border-cyan-400/60 bg-gradient-to-br from-cyan-500/15 to-blue-500/10 ring-1 ring-cyan-400/40 shadow-[0_0_20px_rgba(34,211,238,0.15)]'
                        : 'border-zinc-700/60 bg-zinc-900/20 hover:border-cyan-500/40 hover:bg-zinc-900/40 hover:shadow-[0_0_10px_rgba(34,211,238,0.08)]'
                    }`}
                    whileHover={{ scale: 1.01, y: -1 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <div className="flex items-start gap-3">
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="mt-0.5 flex-shrink-0"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                        >
                          <ChevronRight className="w-4 h-4 text-cyan-400" />
                        </motion.div>
                      )}
                      <div className="flex-1">
                        <div className="flex items-baseline gap-2 mb-2">
                          <span className="text-xs font-mono text-cyan-400/80">{card.lineRange}</span>
                          <span className="text-xs text-zinc-600">•</span>
                          <h3 className="text-sm font-semibold text-zinc-100">{card.title}</h3>
                        </div>
                        <p className="text-sm text-zinc-300/90 leading-relaxed whitespace-pre-wrap">
                          {card.description}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-center">
              <div>
                <p className="text-zinc-400 mb-1">No analysis available</p>
                <p className="text-zinc-500 text-sm">Click the wand icon to analyze this code</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
