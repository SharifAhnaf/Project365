'use client';

import { useEffect, useCallback } from 'react'

export interface KeyboardShortcuts {
  newFile?: () => void
  newFolder?: () => void
  delete?: () => void
  rename?: () => void
  copy?: () => void
  paste?: () => void
  expandAll?: () => void
  collapseAll?: () => void
  search?: () => void
}

export function useKeyboardShortcuts(shortcuts: KeyboardShortcuts) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check if user is typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        // Only handle specific keys that don't conflict with text input
        if (e.key === 'Escape') {
          ;(e.target as HTMLInputElement).blur()
        }
        return
      }

      // Ctrl/Cmd + N: New File
      if ((e.ctrlKey || e.metaKey) && e.key === 'n' && !e.shiftKey) {
        e.preventDefault()
        shortcuts.newFile?.()
        return
      }

      // Ctrl/Cmd + Shift + N: New Folder
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'N') {
        e.preventDefault()
        shortcuts.newFolder?.()
        return
      }

      // Delete: Delete item
      if (e.key === 'Delete') {
        e.preventDefault()
        shortcuts.delete?.()
        return
      }

      // F2 or Ctrl/Cmd + R: Rename
      if (e.key === 'F2' || ((e.ctrlKey || e.metaKey) && e.key === 'r')) {
        e.preventDefault()
        shortcuts.rename?.()
        return
      }

      // Ctrl/Cmd + C: Copy
      if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        e.preventDefault()
        shortcuts.copy?.()
        return
      }

      // Ctrl/Cmd + V: Paste
      if ((e.ctrlKey || e.metaKey) && e.key === 'v') {
        e.preventDefault()
        shortcuts.paste?.()
        return
      }

      // Ctrl/Cmd + Shift + K: Expand All
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'K') {
        e.preventDefault()
        shortcuts.expandAll?.()
        return
      }

      // Ctrl/Cmd + Shift + J: Collapse All
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'J') {
        e.preventDefault()
        shortcuts.collapseAll?.()
        return
      }

      // Ctrl/Cmd + F: Search
      if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
        e.preventDefault()
        shortcuts.search?.()
        return
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [shortcuts])
}

// Shortcut reference for display
export const KEYBOARD_SHORTCUT_REFERENCE = {
  newFile: { keys: ['Ctrl', 'N'], description: 'New File' },
  newFolder: { keys: ['Ctrl', 'Shift', 'N'], description: 'New Folder' },
  delete: { keys: ['Delete'], description: 'Delete' },
  rename: { keys: ['F2'], description: 'Rename' },
  copy: { keys: ['Ctrl', 'C'], description: 'Copy' },
  paste: { keys: ['Ctrl', 'V'], description: 'Paste' },
  expandAll: { keys: ['Ctrl', 'Shift', 'K'], description: 'Expand All' },
  collapseAll: { keys: ['Ctrl', 'Shift', 'J'], description: 'Collapse All' },
  search: { keys: ['Ctrl', 'F'], description: 'Search' },
}
