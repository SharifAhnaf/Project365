import React from 'react'
import {
  Code2,
  FileCode,
  FileJson,
  FileText,
  Database,
  Settings,
  ImageIcon,
  Music,
  Video,
  Archive,
} from 'lucide-react'

const FILE_EXTENSION_MAP: Record<string, { color: string; icon: typeof Code2 }> = {
  // TypeScript/JavaScript
  ts: { color: 'text-blue-400', icon: Code2 },
  tsx: { color: 'text-blue-400', icon: Code2 },
  js: { color: 'text-yellow-400', icon: FileCode },
  jsx: { color: 'text-yellow-400', icon: FileCode },

  // Styling
  css: { color: 'text-purple-400', icon: FileCode },
  scss: { color: 'text-purple-500', icon: FileCode },
  sass: { color: 'text-purple-500', icon: FileCode },
  less: { color: 'text-purple-500', icon: FileCode },

  // Markup
  html: { color: 'text-red-400', icon: Code2 },
  xml: { color: 'text-orange-400', icon: Code2 },
  svg: { color: 'text-orange-400', icon: Code2 },

  // Data Formats
  json: { color: 'text-orange-400', icon: FileJson },
  yaml: { color: 'text-red-500', icon: FileCode },
  yml: { color: 'text-red-500', icon: FileCode },
  toml: { color: 'text-orange-500', icon: FileCode },

  // Python
  py: { color: 'text-cyan-400', icon: Code2 },
  pyw: { color: 'text-cyan-400', icon: Code2 },

  // Java/JVM
  java: { color: 'text-orange-500', icon: Code2 },
  kt: { color: 'text-purple-500', icon: Code2 },
  scala: { color: 'text-red-500', icon: Code2 },

  // Go
  go: { color: 'text-cyan-500', icon: Code2 },

  // Rust
  rs: { color: 'text-orange-600', icon: Code2 },

  // C/C++/C#
  c: { color: 'text-blue-500', icon: Code2 },
  cpp: { color: 'text-blue-600', icon: Code2 },
  cs: { color: 'text-purple-600', icon: Code2 },

  // PHP
  php: { color: 'text-indigo-400', icon: Code2 },

  // Ruby
  rb: { color: 'text-red-600', icon: Code2 },

  // Shell
  sh: { color: 'text-green-400', icon: FileCode },
  bash: { color: 'text-green-400', icon: FileCode },
  zsh: { color: 'text-green-400', icon: FileCode },

  // Documentation
  md: { color: 'text-zinc-300', icon: FileText },
  markdown: { color: 'text-zinc-300', icon: FileText },
  txt: { color: 'text-zinc-300', icon: FileText },
  rst: { color: 'text-zinc-300', icon: FileText },

  // Database
  sql: { color: 'text-green-500', icon: Database },
  db: { color: 'text-green-500', icon: Database },

  // Config
  env: { color: 'text-yellow-500', icon: Settings },
  config: { color: 'text-yellow-500', icon: Settings },
  ini: { color: 'text-yellow-500', icon: Settings },
  conf: { color: 'text-yellow-500', icon: Settings },

  // Media
  jpg: { color: 'text-pink-400', icon: ImageIcon },
  jpeg: { color: 'text-pink-400', icon: ImageIcon },
  png: { color: 'text-pink-400', icon: ImageIcon },
  gif: { color: 'text-pink-400', icon: ImageIcon },
  svg: { color: 'text-pink-400', icon: ImageIcon },
  webp: { color: 'text-pink-400', icon: ImageIcon },

  // Audio
  mp3: { color: 'text-green-500', icon: Music },
  wav: { color: 'text-green-500', icon: Music },
  flac: { color: 'text-green-500', icon: Music },

  // Video
  mp4: { color: 'text-red-500', icon: Video },
  webm: { color: 'text-red-500', icon: Video },
  mov: { color: 'text-red-500', icon: Video },

  // Archives
  zip: { color: 'text-yellow-600', icon: Archive },
  rar: { color: 'text-yellow-600', icon: Archive },
  tar: { color: 'text-yellow-600', icon: Archive },
  gz: { color: 'text-yellow-600', icon: Archive },
  '7z': { color: 'text-yellow-600', icon: Archive },
}

export function getFileIcon(fileName: string): React.ReactNode {
  const ext = fileName.split('.').pop()?.toLowerCase() || ''
  const config = FILE_EXTENSION_MAP[ext]

  if (config) {
    const Icon = config.icon
    return <Icon size={16} className={`${config.color} flex-shrink-0`} />
  }

  return <FileText size={16} className="text-zinc-400 flex-shrink-0" />
}

export function getFileCategory(fileName: string): string {
  const ext = fileName.split('.').pop()?.toLowerCase() || ''

  const categories: Record<string, string[]> = {
    code: ['ts', 'tsx', 'js', 'jsx', 'py', 'java', 'go', 'rs', 'rb', 'php', 'c', 'cpp', 'cs'],
    style: ['css', 'scss', 'sass', 'less'],
    markup: ['html', 'xml', 'svg'],
    data: ['json', 'yaml', 'yml', 'toml', 'sql'],
    documentation: ['md', 'markdown', 'txt', 'rst'],
    config: ['env', 'config', 'ini', 'conf'],
    media: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp3', 'wav', 'mp4', 'webm'],
  }

  for (const [category, extensions] of Object.entries(categories)) {
    if (extensions.includes(ext)) return category
  }

  return 'other'
}

export function isCodeFile(fileName: string): boolean {
  const codeExtensions = [
    'ts',
    'tsx',
    'js',
    'jsx',
    'py',
    'java',
    'go',
    'rs',
    'rb',
    'php',
    'c',
    'cpp',
    'cs',
    'css',
    'scss',
    'html',
    'sql',
    'sh',
    'bash',
  ]
  const ext = fileName.split('.').pop()?.toLowerCase() || ''
  return codeExtensions.includes(ext)
}
