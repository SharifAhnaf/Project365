// Server-side rate limiter using Map-based in-memory storage
// In production, use Redis or similar for distributed rate limiting

interface RateLimitEntry {
  count: number
  resetTime: number
}

const rateLimitMap = new Map<string, RateLimitEntry>()

// Cleanup old entries every minute to prevent memory leaks
setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of rateLimitMap.entries()) {
    if (entry.resetTime < now) {
      rateLimitMap.delete(key)
    }
  }
}, 60000)

export function createRateLimiter(requestsPerMinute: number = 10) {
  return function isRateLimited(identifier: string): boolean {
    const now = Date.now()
    const key = `rate-limit:${identifier}`
    const entry = rateLimitMap.get(key)

    if (!entry || entry.resetTime < now) {
      // Reset or create new entry
      rateLimitMap.set(key, {
        count: 1,
        resetTime: now + 60000, // 1 minute from now
      })
      return false // Not rate limited
    }

    if (entry.count >= requestsPerMinute) {
      return true // Rate limited
    }

    entry.count++
    return false // Not rate limited
  }
}

// Create specific limiters for different endpoints
export const analyzeRateLimiter = createRateLimiter(5) // 5 requests per minute
export const chatRateLimiter = createRateLimiter(10) // 10 requests per minute
