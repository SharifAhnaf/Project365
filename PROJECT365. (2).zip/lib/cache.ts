// Simple in-memory cache with TTL for API responses
// For production, integrate with Redis or similar

interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number
}

const cache = new Map<string, CacheEntry<any>>()

// Cleanup expired cache entries every 5 minutes
setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of cache.entries()) {
    if (now - entry.timestamp > entry.ttl) {
      cache.delete(key)
    }
  }
}, 300000)

export function createCacheKey(type: string, input: string): string {
  // Create a simple hash of the input to use as cache key
  const hash = input
    .split('')
    .reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 0)
    .toString(36)
  return `${type}:${hash}`
}

export function getCachedResponse<T>(key: string): T | null {
  const entry = cache.get(key)
  if (!entry) return null

  const now = Date.now()
  if (now - entry.timestamp > entry.ttl) {
    cache.delete(key)
    return null
  }

  return entry.data as T
}

export function setCachedResponse<T>(key: string, data: T, ttlMs: number = 3600000): void {
  cache.set(key, {
    data,
    timestamp: Date.now(),
    ttl: ttlMs,
  })
}

export function clearCache(): void {
  cache.clear()
}

export function getCacheStats(): {
  size: number
  entries: number
} {
  return {
    size: cache.size,
    entries: cache.size,
  }
}
