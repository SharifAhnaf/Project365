/**
 * Code Chunker Utility
 * Splits code into manageable chunks to handle API limits
 */

export interface CodeChunk {
  content: string
  rawContent: string // Original code without line numbers
  startLine: number
  endLine: number
  chunkIndex: number
  totalChunks: number
  lineMap: Map<number, string> // Maps original line numbers to content
}

/**
 * Splits code into chunks of specified line count with line number mapping
 * @param code The full code string to split
 * @param linesPerChunk Number of lines per chunk (default: 30)
 * @returns Array of code chunks with line numbers and mappings
 */
export function splitCodeIntoChunks(code: string, linesPerChunk: number = 30): CodeChunk[] {
  const lines = code.split('\n')
  const chunks: CodeChunk[] = []
  
  for (let i = 0; i < lines.length; i += linesPerChunk) {
    const chunkLines = lines.slice(i, i + linesPerChunk)
    const chunkIndex = Math.floor(i / linesPerChunk)
    const totalChunks = Math.ceil(lines.length / linesPerChunk)
    const startLine = i + 1 // Line numbers are 1-indexed
    const endLine = Math.min(i + linesPerChunk, lines.length)
    
    // Create line number mapping for this chunk
    const lineMap = new Map<number, string>()
    chunkLines.forEach((line, idx) => {
      lineMap.set(startLine + idx, line)
    })
    
    // Use raw content for logical block analysis (no line brackets)
    const rawContent = chunkLines.join('\n')
    
    chunks.push({
      content: rawContent,
      rawContent: rawContent,
      startLine,
      endLine,
      chunkIndex,
      totalChunks,
      lineMap,
    })
  }
  
  return chunks
}

/**
 * Determines if code should be chunked based on line count
 * @param code The code to check
 * @param threshold Number of lines before chunking is needed (default: 400)
 * @returns true if code exceeds threshold
 */
export function shouldChunkCode(code: string, threshold: number = 400): boolean {
  return code.split('\n').length > threshold
}

/**
 * Prepares chunk-specific context for the translation prompt
 * @param chunk The code chunk
 * @param fileName Original file name
 * @returns Context string for the API prompt
 */
export function getChunkContext(chunk: CodeChunk, fileName: string): string {
  const chunkInfo = chunk.totalChunks > 1 
    ? ` [Part ${chunk.chunkIndex + 1} of ${chunk.totalChunks}, Lines ${chunk.startLine}-${chunk.endLine}]`
    : ''
  return `File: ${fileName}${chunkInfo}`
}

/**
 * Combines translations from multiple chunks into a single output
 * @param translations Array of translation strings from each chunk
 * @param chunks Array of chunk metadata
 * @returns Combined translation seamlessly joined
 */
export function combineChunkTranslations(translations: string[], chunks: CodeChunk[]): string {
  if (chunks.length === 1) {
    return translations[0]
  }
  
  // Seamlessly combine all translations without headers
  return translations.join('\n\n')
}
