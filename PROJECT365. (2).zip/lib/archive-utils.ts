import JSZip from 'jszip'

export interface ExtractedFile {
  name: string
  content: string
  path: string
  isDirectory: boolean
}

export async function extractZipFile(file: File): Promise<ExtractedFile[]> {
  const zip = new JSZip()
  const contents = await zip.loadAsync(file)
  const files: ExtractedFile[] = []

  for (const [path, zipEntry] of Object.entries(contents.files)) {
    if (zipEntry.dir) {
      files.push({
        name: path.split('/').filter(Boolean).pop() || path,
        content: '',
        path: path,
        isDirectory: true,
      })
    } else {
      const content = await zipEntry.async('text')
      files.push({
        name: path.split('/').pop() || path,
        content: content,
        path: path,
        isDirectory: false,
      })
    }
  }

  return files
}

export async function extractRarFile(file: File): Promise<ExtractedFile[]> {
  // For RAR files, we'll need a specialized approach
  // Since RAR extraction in JavaScript is limited, we'll read common archive formats
  // For now, we'll detect RAR and provide a helpful message or use alternative approach
  
  try {
    // Try to use unrar.js if available
    const buffer = await file.arrayBuffer()
    const header = new Uint8Array(buffer).slice(0, 7)
    const isRar = String.fromCharCode(...header).startsWith('Rar!')
    
    if (isRar) {
      // RAR format detected but we need external processing
      // For now, return a message file
      return [{
        name: 'README.txt',
        content: `RAR archives require external tools to extract. Please use WinRAR, 7-Zip, or the rar command line tool to extract this archive first, then upload the extracted files.

For now, you can still view the RAR file as text.`,
        path: 'README.txt',
        isDirectory: false,
      }]
    }
  } catch (error) {
    console.error('Error checking file format:', error)
  }

  return []
}

export async function extractArchive(file: File): Promise<ExtractedFile[]> {
  const fileName = file.name.toLowerCase()
  
  if (fileName.endsWith('.zip')) {
    return extractZipFile(file)
  } else if (fileName.endsWith('.rar')) {
    return extractRarFile(file)
  } else if (fileName.endsWith('.tar') || fileName.endsWith('.tar.gz') || fileName.endsWith('.tgz')) {
    // TAR files would need a tar extraction library
    return []
  }
  
  return []
}

export function isArchiveFile(fileName: string): boolean {
  const name = fileName.toLowerCase()
  return name.endsWith('.zip') || name.endsWith('.rar') || name.endsWith('.tar') || name.endsWith('.tar.gz') || name.endsWith('.tgz')
}
