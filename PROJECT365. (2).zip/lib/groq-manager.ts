/**
 * Groq API Manager - Comprehensive management system for Groq API interactions
 * Handles: API key validation, quota tracking, usage analytics, error handling
 */

interface APIUsageMetric {
  endpoint: string
  timestamp: number
  tokensUsed: number
  responseTime: number
  status: 'success' | 'error' | 'rate-limited'
  model: string
  mode?: string
}

interface QuotaInfo {
  remainingRequests: number
  resetTime: number
  requestsThisMinute: number
  requestsThisHour: number
  dailyLimit: number
  dailyUsed: number
}

interface GroqConfig {
  apiKey: string
  isConfigured: boolean
  model: string
  maxTokens: number
  requestsPerMinute: number
  requestsPerHour: number
  dailyLimit: number
}

class GroqAPIManager {
  private usageMetrics: APIUsageMetric[] = []
  private config: GroqConfig = {
    apiKey: process.env.GROQ_API_KEY || '',
    isConfigured: !!process.env.GROQ_API_KEY,
    model: 'llama-3.3-70b-versatile',
    maxTokens: 4096,
    requestsPerMinute: 30,
    requestsPerHour: 300,
    dailyLimit: 2000,
  }

  private requestTimestamps: number[] = []
  private errorLog: Array<{
    timestamp: number
    endpoint: string
    error: string
    details: any
  }> = []

  constructor() {
    this.validateConfiguration()
    this.startCleanupInterval()
  }

  /**
   * Validate Groq API configuration
   */
  private validateConfiguration(): void {
    if (!this.config.isConfigured) {
      console.warn(
        '[Groq Manager] Warning: GROQ_API_KEY is not configured. API calls will fail.'
      )
    } else {
      console.log('[Groq Manager] Groq API is properly configured')
    }
  }

  /**
   * Get current API configuration
   */
  getConfig(): GroqConfig {
    return { ...this.config }
  }

  /**
   * Check if API is ready for requests
   */
  isAPIReady(): boolean {
    return this.config.isConfigured && !!this.config.apiKey
  }

  /**
   * Record API usage for analytics
   */
  recordUsage(metric: Omit<APIUsageMetric, 'timestamp'>): void {
    const fullMetric: APIUsageMetric = {
      ...metric,
      timestamp: Date.now(),
    }
    this.usageMetrics.push(fullMetric)
    this.requestTimestamps.push(Date.now())

    // Keep last 1000 metrics
    if (this.usageMetrics.length > 1000) {
      this.usageMetrics = this.usageMetrics.slice(-1000)
    }
  }

  /**
   * Record API errors
   */
  recordError(endpoint: string, error: any, details?: any): void {
    this.errorLog.push({
      timestamp: Date.now(),
      endpoint,
      error: error?.message || String(error),
      details,
    })

    // Keep last 100 errors
    if (this.errorLog.length > 100) {
      this.errorLog = this.errorLog.slice(-100)
    }
  }

  /**
   * Get quota information
   */
  getQuotaInfo(): QuotaInfo {
    const now = Date.now()
    const oneMinuteAgo = now - 60000
    const oneHourAgo = now - 3600000

    const requestsThisMinute = this.requestTimestamps.filter((t) => t > oneMinuteAgo).length
    const requestsThisHour = this.requestTimestamps.filter((t) => t > oneHourAgo).length

    // Calculate daily usage (assuming day resets at midnight UTC)
    const todayStart = new Date(now)
    todayStart.setUTCHours(0, 0, 0, 0)
    const requestsToday = this.requestTimestamps.filter((t) => t >= todayStart.getTime()).length

    return {
      remainingRequests: Math.max(
        0,
        this.config.requestsPerMinute - requestsThisMinute
      ),
      resetTime: Math.ceil((60000 - (now % 60000)) / 1000), // Seconds until minute resets
      requestsThisMinute,
      requestsThisHour,
      dailyLimit: this.config.dailyLimit,
      dailyUsed: requestsToday,
    }
  }

  /**
   * Check if request should be rate limited
   */
  shouldRateLimit(): boolean {
    const quota = this.getQuotaInfo()
    return (
      quota.requestsThisMinute >= this.config.requestsPerMinute ||
      quota.requestsThisHour >= this.config.requestsPerHour ||
      quota.dailyUsed >= this.config.dailyLimit
    )
  }

  /**
   * Get usage statistics
   */
  getUsageStats() {
    const successCount = this.usageMetrics.filter((m) => m.status === 'success').length
    const errorCount = this.usageMetrics.filter((m) => m.status === 'error').length
    const rateLimitedCount = this.usageMetrics.filter((m) => m.status === 'rate-limited').length

    const avgResponseTime =
      this.usageMetrics.length > 0
        ? this.usageMetrics.reduce((sum, m) => sum + m.responseTime, 0) / this.usageMetrics.length
        : 0

    const successRate =
      this.usageMetrics.length > 0
        ? (successCount / this.usageMetrics.length) * 100
        : 0

    return {
      totalRequests: this.usageMetrics.length,
      successCount,
      errorCount,
      rateLimitedCount,
      successRate: successRate.toFixed(2),
      averageResponseTime: avgResponseTime.toFixed(0),
      recentMetrics: this.usageMetrics.slice(-10),
    }
  }

  /**
   * Get recent errors
   */
  getRecentErrors(limit: number = 10) {
    return this.errorLog.slice(-limit).reverse()
  }

  /**
   * Get metrics by endpoint
   */
  getMetricsByEndpoint(endpoint: string) {
    const metrics = this.usageMetrics.filter((m) => m.endpoint === endpoint)
    const successCount = metrics.filter((m) => m.status === 'success').length
    const avgResponseTime =
      metrics.length > 0
        ? metrics.reduce((sum, m) => sum + m.responseTime, 0) / metrics.length
        : 0

    return {
      endpoint,
      totalCalls: metrics.length,
      successCount,
      failureCount: metrics.length - successCount,
      averageResponseTime: avgResponseTime.toFixed(0),
    }
  }

  /**
   * Get all endpoints usage
   */
  getAllEndpointsUsage() {
    const endpoints = new Set(this.usageMetrics.map((m) => m.endpoint))
    return Array.from(endpoints).map((endpoint) =>
      this.getMetricsByEndpoint(endpoint)
    )
  }

  /**
   * Clear all metrics and error logs
   */
  resetMetrics(): void {
    this.usageMetrics = []
    this.requestTimestamps = []
    this.errorLog = []
    console.log('[Groq Manager] Metrics and error logs cleared')
  }

  /**
   * Update configuration
   */
  updateConfig(newConfig: Partial<GroqConfig>): void {
    this.config = { ...this.config, ...newConfig }
    console.log('[Groq Manager] Configuration updated:', this.config)
  }

  /**
   * Get health status
   */
  getHealthStatus() {
    const quota = this.getQuotaInfo()
    const stats = this.getUsageStats()

    return {
      apiConfigured: this.config.isConfigured,
      recentErrorCount: this.errorLog.filter((e) => Date.now() - e.timestamp < 3600000).length,
      quotaStatus: {
        minuteUsage: `${quota.requestsThisMinute}/${this.config.requestsPerMinute}`,
        hourUsage: `${quota.requestsThisHour}/${this.config.requestsPerHour}`,
        dailyUsage: `${quota.dailyUsed}/${this.config.dailyLimit}`,
        minuteRemaining: quota.remainingRequests,
      },
      performanceMetrics: {
        totalRequests: stats.totalRequests,
        successRate: stats.successRate,
        averageResponseTime: `${stats.averageResponseTime}ms`,
      },
      status: this.getOverallHealth(),
    }
  }

  /**
   * Determine overall health status
   */
  private getOverallHealth(): 'healthy' | 'degraded' | 'critical' {
    const quota = this.getQuotaInfo()
    const stats = this.getUsageStats()
    const successRate = parseFloat(stats.successRate)

    if (!this.config.isConfigured) return 'critical'
    if (quota.requestsThisMinute >= this.config.requestsPerMinute) return 'critical'
    if (successRate < 50) return 'critical'
    if (quota.requestsThisMinute > this.config.requestsPerMinute * 0.8) return 'degraded'
    if (successRate < 80) return 'degraded'

    return 'healthy'
  }

  /**
   * Cleanup interval - remove old timestamps
   */
  private startCleanupInterval(): void {
    setInterval(() => {
      const now = Date.now()
      const oneDayAgo = now - 86400000

      // Keep only timestamps from the last 24 hours
      this.requestTimestamps = this.requestTimestamps.filter((t) => t > oneDayAgo)
    }, 600000) // Run every 10 minutes
  }

  /**
   * Export analytics data
   */
  exportAnalytics() {
    return {
      exportedAt: new Date().toISOString(),
      config: this.config,
      quotaInfo: this.getQuotaInfo(),
      usageStats: this.getUsageStats(),
      endpointsUsage: this.getAllEndpointsUsage(),
      recentErrors: this.getRecentErrors(20),
      healthStatus: this.getHealthStatus(),
    }
  }
}

// Export singleton instance
export const groqManager = new GroqAPIManager()
