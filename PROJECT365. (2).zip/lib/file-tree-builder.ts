export interface FileNode {
  id: string
  name: string
  type: 'file' | 'folder'
  path: string
  content?: string
  children?: FileNode[]
  expanded?: boolean
  parentId?: string
}

interface PathNode {
  node: FileNode
  children: Map<string, PathNode>
}

/**
 * Builds a precise hierarchical file tree from extracted files,
 * preserving exact directory structure and organization
 */
export function buildHierarchicalFileTree(files: Array<{ name: string; path: string; content: string; isDirectory: boolean }>): FileNode[] {
  const root: FileNode = {
    id: generateId(),
    name: 'Project',
    type: 'folder',
    path: '',
    expanded: true,
    children: [],
  }

  const pathMap = new Map<string, FileNode>()
  pathMap.set('', root)

  // Sort files by path depth to ensure parent folders exist before children
  const sorted = [...files].sort((a, b) => {
    const aDepth = (a.path.match(/\//g) || []).length
    const bDepth = (b.path.match(/\//g) || []).length
    return aDepth - bDepth
  })

  for (const file of sorted) {
    const normalizedPath = file.path.replace(/\\/g, '/').trim()
    const pathParts = normalizedPath.split('/').filter(Boolean)

    if (pathParts.length === 0) continue

    // Create all parent directories if they don't exist
    let currentPath = ''
    for (let i = 0; i < pathParts.length - 1; i++) {
      currentPath = currentPath ? `${currentPath}/${pathParts[i]}` : pathParts[i]

      if (!pathMap.has(currentPath)) {
        const folderName = pathParts[i]
        const folderNode: FileNode = {
          id: generateId(),
          name: folderName,
          type: 'folder',
          path: currentPath,
          children: [],
          expanded: false,
        }

        const parentPath = currentPath.split('/').slice(0, -1).join('/')
        const parent = pathMap.get(parentPath) || root

        if (!parent.children) parent.children = []
        parent.children.push(folderNode)
        pathMap.set(currentPath, folderNode)
      }
    }

    // Create the file node
    const fileName = pathParts[pathParts.length - 1]
    const fullPath = normalizedPath
    const parentPath = pathParts.slice(0, -1).join('/')

    if (!pathMap.has(fullPath)) {
      const fileNode: FileNode = {
        id: generateId(),
        name: fileName,
        type: file.isDirectory ? 'folder' : 'file',
        path: fullPath,
        content: file.isDirectory ? undefined : file.content,
        children: file.isDirectory ? [] : undefined,
        expanded: false,
      }

      const parent = pathMap.get(parentPath) || root

      if (!parent.children) parent.children = []
      parent.children.push(fileNode)
      pathMap.set(fullPath, fileNode)
    }
  }

  // Sort children alphabetically at each level (folders first, then files)
  sortFileTreeChildren(root)

  return [root]
}

/**
 * Recursively sorts children in the file tree
 * Folders appear before files, both sorted alphabetically
 */
function sortFileTreeChildren(node: FileNode): void {
  if (node.children) {
    node.children.sort((a, b) => {
      // Folders come before files
      if (a.type !== b.type) {
        return a.type === 'folder' ? -1 : 1
      }
      // Same type, sort alphabetically
      return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' })
    })

    // Recursively sort children
    for (const child of node.children) {
      sortFileTreeChildren(child)
    }
  }
}

/**
 * Flattens the file tree into a list for operations like search/filter
 */
export function flattenFileTree(root: FileNode): FileNode[] {
  const result: FileNode[] = [root]

  const traverse = (node: FileNode) => {
    if (node.children) {
      for (const child of node.children) {
        result.push(child)
        traverse(child)
      }
    }
  }

  traverse(root)
  return result
}

/**
 * Finds a file node by its ID in the tree
 */
export function findFileNodeById(id: string, root: FileNode): FileNode | null {
  if (root.id === id) return root

  if (root.children) {
    for (const child of root.children) {
      const found = findFileNodeById(id, child)
      if (found) return found
    }
  }

  return null
}

/**
 * Finds a file node by its path
 */
export function findFileNodeByPath(path: string, root: FileNode): FileNode | null {
  if (root.path === path) return root

  if (root.children) {
    for (const child of root.children) {
      const found = findFileNodeByPath(path, child)
      if (found) return found
    }
  }

  return null
}

/**
 * Counts total files and folders in the tree
 */
export function countTreeItems(node: FileNode): { files: number; folders: number } {
  let files = node.type === 'file' ? 1 : 0
  let folders = node.type === 'folder' ? 1 : 0

  if (node.children) {
    for (const child of node.children) {
      const counts = countTreeItems(child)
      files += counts.files
      folders += counts.folders
    }
  }

  return { files, folders }
}

/**
 * Gets file tree statistics for display
 */
export function getTreeStats(nodes: FileNode[]): { totalFiles: number; totalFolders: number; totalSize: number } {
  let totalFiles = 0
  let totalFolders = 0
  let totalSize = 0

  const traverse = (node: FileNode) => {
    const counts = countTreeItems(node)
    totalFiles += counts.files
    totalFolders += counts.folders

    if (node.content) {
      totalSize += node.content.length
    }

    if (node.children) {
      for (const child of node.children) {
        traverse(child)
      }
    }
  }

  for (const node of nodes) {
    traverse(node)
  }

  return { totalFiles, totalFolders, totalSize }
}

/**
 * Generates a unique ID for file nodes
 */
function generateId(): string {
  return `node-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
}
