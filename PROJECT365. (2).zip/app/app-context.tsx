'use client'

import React, { createContext, useContext, useState, useCallback, useMemo } from 'react'
import type { ExtractedFile } from '@/lib/archive-utils'
import { buildHierarchicalFileTree } from '@/lib/file-tree-builder'

interface FileNode {
  id: string
  name: string
  type: 'file' | 'folder'
  content?: string
  children?: FileNode[]
  expanded?: boolean
  parentId?: string
}

interface TranslationState {
  content: string
  fromCache: boolean
}

interface AppContextError {
  type: 'file_operation' | 'translation' | 'network'
  message: string
  timestamp: number
}

interface AppContextType {
  // File state
  files: FileNode[]
  selectedFileId: string | null
  selectedFile: FileNode | null
  
  // Translation state
  translation: TranslationState
  isLoadingTranslation: boolean
  lastError: AppContextError | null
  
  // File operations
  selectFile: (fileId: string) => void
  updateFileContent: (fileId: string, content: string) => void
  toggleFolder: (fileId: string) => void
  addFile: (parentId: string, name: string, content?: string) => void
  deleteFile: (fileId: string) => void
  renameFile: (fileId: string, newName: string) => void
  setFiles: (files: FileNode[]) => void
  
  // Translation operations
  setTranslation: (translation: TranslationState) => void
  setIsLoadingTranslation: (loading: boolean) => void
  generateTranslation: (code: string, fileName: string) => Promise<any>
  clearError: () => void
  
  // File tree operations
  buildFileTreeFromExtracted: (extractedFiles: ExtractedFile[]) => FileNode[]
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [files, setFiles] = useState<FileNode[]>([])
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null)
  const [translation, setTranslation] = useState<TranslationState>({
    content: '',
    fromCache: false,
  })
  const [isLoadingTranslation, setIsLoadingTranslation] = useState(false)
  const [lastError, setLastError] = useState<AppContextError | null>(null)

  // Optimized file lookup with early exit
  const findFile = useCallback((fileId: string, nodes: FileNode[] = files): FileNode | null => {
    const stack = [...nodes]
    while (stack.length > 0) {
      const node = stack.pop()!
      if (node.id === fileId) return node
      if (node.children?.length) stack.push(...node.children)
    }
    return null
  }, [files])

  // Optimized parent lookup with early exit
  const findFileParent = useCallback((fileId: string, nodes: FileNode[] = files, parent: FileNode | null = null): FileNode | null => {
    const stack = nodes.map((n) => ({ node: n, parent: null as FileNode | null }))
    while (stack.length > 0) {
      const { node, parent: currentParent } = stack.pop()!
      if (node.id === fileId) return currentParent
      if (node.children?.length) {
        stack.push(...node.children.map((n) => ({ node: n, parent: node })))
      }
    }
    return null
  }, [files])

  // Optimized tree update function
  const updateFileInTree = useCallback(
    (fileId: string, updater: (node: FileNode) => FileNode, nodes: FileNode[] = files): FileNode[] => {
      let found = false
      const result = nodes.map((node) => {
        if (node.id === fileId) {
          found = true
          return updater(node)
        }
        if (node.children && !found) {
          return {
            ...node,
            children: updateFileInTree(fileId, updater, node.children),
          }
        }
        return node
      })
      return result
    },
    [files],
  )

  const selectFile = useCallback((fileId: string) => {
    const file = findFile(fileId)
    if (!file) {
      setLastError({
        type: 'file_operation',
        message: 'File not found',
        timestamp: Date.now(),
      })
      return
    }
    setSelectedFileId(fileId)
    setLastError(null)
  }, [findFile])

  const updateFileContent = useCallback(
    (fileId: string, content: string) => {
      try {
        setFiles((prev) => updateFileInTree(fileId, (node) => ({ ...node, content }), prev))
        setLastError(null)
      } catch (error) {
        setLastError({
          type: 'file_operation',
          message: 'Failed to update file content',
          timestamp: Date.now(),
        })
      }
    },
    [updateFileInTree],
  )

  const toggleFolder = useCallback(
    (fileId: string) => {
      try {
        setFiles((prev) => updateFileInTree(fileId, (node) => ({ ...node, expanded: !node.expanded }), prev))
        setLastError(null)
      } catch (error) {
        setLastError({
          type: 'file_operation',
          message: 'Failed to toggle folder',
          timestamp: Date.now(),
        })
      }
    },
    [updateFileInTree],
  )

  const addFile = useCallback(
    (parentId: string, name: string, content = '') => {
      try {
        if (!name.trim()) {
          setLastError({
            type: 'file_operation',
            message: 'File name cannot be empty',
            timestamp: Date.now(),
          })
          return
        }

        const newFile: FileNode = {
          id: `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name,
          type: content ? 'file' : 'folder',
          content,
          parentId,
          children: content ? undefined : [],
        }

        setFiles((prev) =>
          updateFileInTree(
            parentId,
            (node) => ({
              ...node,
              children: [...(node.children || []), newFile],
            }),
            prev,
          ),
        )
        setLastError(null)
      } catch (error) {
        setLastError({
          type: 'file_operation',
          message: 'Failed to add file',
          timestamp: Date.now(),
        })
      }
    },
    [updateFileInTree],
  )

  const deleteFile = useCallback(
    (fileId: string) => {
      try {
        const parent = findFileParent(fileId)
        if (parent) {
          setFiles((prev) =>
            updateFileInTree(
              parent.id,
              (node) => ({
                ...node,
                children: node.children?.filter((child) => child.id !== fileId),
              }),
              prev,
            ),
          )
        } else {
          setFiles((prev) => prev.filter((node) => node.id !== fileId))
        }

        if (selectedFileId === fileId) {
          setSelectedFileId(null)
        }
        setLastError(null)
      } catch (error) {
        setLastError({
          type: 'file_operation',
          message: 'Failed to delete file',
          timestamp: Date.now(),
        })
      }
    },
    [findFileParent, updateFileInTree, selectedFileId],
  )

  const renameFile = useCallback(
    (fileId: string, newName: string) => {
      try {
        if (!newName.trim()) {
          setLastError({
            type: 'file_operation',
            message: 'File name cannot be empty',
            timestamp: Date.now(),
          })
          return
        }

        setFiles((prev) =>
          updateFileInTree(
            fileId,
            (node) => ({ ...node, name: newName }),
            prev,
          ),
        )
        setLastError(null)
      } catch (error) {
        setLastError({
          type: 'file_operation',
          message: 'Failed to rename file',
          timestamp: Date.now(),
        })
      }
    },
    [updateFileInTree],
  )

  const buildFileTreeFromExtracted = useCallback((extractedFiles: ExtractedFile[]): FileNode[] => {
    try {
      return buildHierarchicalFileTree(
        extractedFiles.map((file) => ({
          name: file.name,
          path: file.path,
          content: file.content,
          isDirectory: file.isDirectory,
        })),
      )
    } catch (error) {
      setLastError({
        type: 'file_operation',
        message: 'Failed to build file tree',
        timestamp: Date.now(),
      })
      return []
    }
  }, [])

  const generateTranslation = useCallback(
    async (code: string, fileName: string) => {
      if (!code.trim()) {
        setLastError({
          type: 'translation',
          message: 'Code cannot be empty',
          timestamp: Date.now(),
        })
        return { quotaExceeded: false, isDemo: false }
      }

      setIsLoadingTranslation(true)
      const startTime = Date.now()

      try {
        const controller = new AbortController()
        const timeout = setTimeout(() => controller.abort(), 30000) // 30s timeout

        const response = await fetch('/api/translate-contextual', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code, fileName, mode: 'plain-english' }),
          signal: controller.signal,
        })

        clearTimeout(timeout)

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`)
        }

        const data = await response.json()

        if (data?.translation) {
          setTranslation({
            content: data.translation,
            fromCache: data.fromCache ?? false,
          })
          setLastError(null)
        }

        return data
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error'
        const isNetworkError = errorMessage.includes('Failed to fetch') || errorMessage.includes('AbortError')

        setLastError({
          type: isNetworkError ? 'network' : 'translation',
          message: isNetworkError ? 'Network error - check your connection' : `Translation failed: ${errorMessage}`,
          timestamp: Date.now(),
        })

        setTranslation({
          content: '',
          fromCache: false,
        })

        return { quotaExceeded: false, isDemo: false, error: errorMessage }
      } finally {
        setIsLoadingTranslation(false)
      }
    },
    [],
  )

  // Memoize selectedFile to prevent unnecessary recalculations
  const selectedFile = useMemo(() => findFile(selectedFileId), [selectedFileId, findFile])

  const clearError = useCallback(() => {
    setLastError(null)
  }, [])

  const value: AppContextType = useMemo(
    () => ({
      files,
      selectedFileId,
      selectedFile,
      translation,
      isLoadingTranslation,
      lastError,
      setFiles,
      selectFile,
      updateFileContent,
      toggleFolder,
      addFile,
      deleteFile,
      renameFile,
      setTranslation,
      setIsLoadingTranslation,
      generateTranslation,
      buildFileTreeFromExtracted,
      clearError,
    }),
    [
      files,
      selectedFileId,
      selectedFile,
      translation,
      isLoadingTranslation,
      lastError,
      selectFile,
      updateFileContent,
      toggleFolder,
      addFile,
      deleteFile,
      renameFile,
      generateTranslation,
      buildFileTreeFromExtracted,
      clearError,
    ],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error('useAppContext must be used within AppProvider')
  }
  return context
}
