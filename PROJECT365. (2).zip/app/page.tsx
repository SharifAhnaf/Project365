'use client'

import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable'
import { Sidebar } from '@/components/sidebar'
import { Workspace } from '@/components/workspace'
import { AppProvider } from '@/app/app-context'

export default function Home() {
  return (
    <AppProvider>
      <div className="h-screen w-screen bg-black flex">
        <ResizablePanelGroup direction="horizontal" className="h-full w-full">
          {/* Left Panel: Sidebar */}
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30} className="bg-zinc-950">
            <Sidebar />
          </ResizablePanel>

          <ResizableHandle withHandle className="bg-zinc-800" />

          {/* Center Panel: Workspace */}
          <ResizablePanel defaultSize={80} minSize={70} className="flex-1">
            <Workspace />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </AppProvider>
  )
}
