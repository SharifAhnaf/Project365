'use server'

import { generateText } from 'ai'
import { groq } from '@ai-sdk/groq'

export async function analyzeCode(code: string, fileName: string): Promise<string> {
  try {
    // Check if API key is available
    if (!process.env.GROQ_API_KEY) {
      return 'Groq API key not configured. Please add GROQ_API_KEY to your environment variables.'
    }

    const codeLines = code.split('\n').length
    const { text } = await generateText({
      model: groq('llama-3.3-70b-versatile'),
      prompt: `You are an expert code educator and analyzer. Analyze this code file in EXTREME detail, explaining EVERY line.

File name: ${fileName}
Total Lines: ${codeLines}

Code:
\`\`\`
${code}
\`\`\`

CRITICAL: You must explain EVERY SINGLE LINE of code. Do not skip any lines, even simple ones.

Provide a comprehensive line-by-line breakdown explaining exactly what each line does, its purpose, and why it matters.`,
    })
    return text
  } catch (error) {
    console.error('Error analyzing code:', error)
    return 'Unable to analyze code at this moment. Please try again.'
  }
}
