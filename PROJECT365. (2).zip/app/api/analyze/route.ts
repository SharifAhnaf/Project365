import { generateText } from 'ai'
import { createGroq } from '@ai-sdk/groq'
import { analyzeRateLimiter } from '@/lib/rate-limiter'
import { createCacheKey, getCachedResponse, setCachedResponse } from '@/lib/cache'
import { groqManager } from '@/lib/groq-manager'

// Initialize Groq client
const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

export async function POST(request: Request) {
  let code = ''
  let fileName = ''

  try {
    const body = await request.json()
    code = body.code
    fileName = body.fileName

    // Check if API key is available
    if (!process.env.GROQ_API_KEY) {
      return Response.json(
        {
          translation: 'Groq API key not configured. Please add GROQ_API_KEY to your environment variables.',
          isDemo: true,
          error: 'Missing API key',
        },
        { status: 200 }
      )
    }

    // Check cache first
    const cacheKey = createCacheKey('analyze', code)
    const cachedResult = getCachedResponse(cacheKey)
    if (cachedResult) {
      console.log('[v0] Cache hit for analysis')
      return Response.json({ ...cachedResult, fromCache: true }, { status: 200 })
    }

    // Check rate limit
    if (analyzeRateLimiter(`analyze:${code.slice(0, 50)}`)) {
      console.log('[v0] Rate limit exceeded for analyze endpoint')
      return Response.json(
        {
          translation: 'Too many requests. Please wait a moment before analyzing another file.',
          isDemo: true,
          rateLimited: true,
          error: 'Rate limit exceeded (5 requests per minute)',
        },
        { status: 429 }
      )
    }

    try {
      const startTime = Date.now()
      const codeLines = code.split('\n').length
      
      const { text } = await generateText({
        model: groq.chat('llama-3.3-70b-versatile'),
        prompt: `You are an expert code educator and analyzer. Analyze this code file and explain it in plain English using logical blocks.

ANALYSIS APPROACH - LOGICAL BLOCKS:
Analyze the provided code and identify the main logical blocks (functions, classes, loops, or major sections). For each block:
1. Create a descriptive header (e.g., ## User Authentication Logic)
2. Provide a clear, high-level explanation of what that section does
3. Group related lines together in a paragraph
4. Explain the purpose and outcome of that block
5. Use markdown formatting with headers (##), bold text for variable names, and bullet points for steps

FORMATTING REQUIREMENTS:
- Use markdown syntax (##, **bold**, bullet points)
- Format variable names in **bold** (e.g., **userName**, **isValid**)
- Use clear section headers describing the logical block
- Write explanations as prose paragraphs, not line-by-line
- Group related functionality together
- Map clearly to code sections (e.g., 'In the first section...', 'Inside the main loop...')
- Use bullet points to describe key operations and data flow

STRUCTURE YOUR RESPONSE:
1. **Overview**: What does this code do at a high level?
2. **Purpose & Use Case**: Why would someone write this? What problem does it solve?
3. **Logical Block Breakdown**: For each significant block in the code:
   - Create a descriptive header (## Block Name)
   - Explain what this block does and why it matters
   - Describe the data flow and state changes
   - Highlight key operations
4. **Key Concepts**: Any important programming concepts used
5. **Potential Issues**: Edge cases or things to watch out for
6. **How to Improve**: Suggestions for making this code better

DO NOT:
- Do NOT translate line-by-line
- Do NOT include line numbers
- Do NOT be overly technical
- Do NOT include "Part X" headers

File: ${fileName}
Total Code Lines: ${codeLines}

Code to Analyze:
\`\`\`
${code}
\`\`\`

Now analyze the code and provide logical block explanations with professional markdown formatting:`,
      })

      const responseTime = Date.now() - startTime

      // Record successful usage
      groqManager.recordUsage({
        endpoint: '/api/analyze',
        tokensUsed: text.length,
        responseTime,
        status: 'success',
        model: 'llama-3.3-70b-versatile',
      })

      const result = { translation: text, isDemo: false, quotaExceeded: false }
      // Cache successful responses for 1 hour
      setCachedResponse(cacheKey, result, 3600000)

      return Response.json(result, { status: 200 })
    } catch (apiError: any) {
      const errorMessage = apiError?.message || JSON.stringify(apiError)
      console.error('[v0] Groq API Error:', errorMessage)

      // Record error usage
      groqManager.recordError('/api/analyze', apiError, {
        codeLength: code.length,
      })

      // Check if it's a rate limit error (429)
      const isRateLimitError =
        errorMessage.includes('rate limit') ||
        errorMessage.includes('quota') ||
        apiError?.status === 429

      if (isRateLimitError) {
        console.log('[v0] Groq rate limit hit, returning rate limit flag')
        
        // Record rate limit hit
        groqManager.recordUsage({
          endpoint: '/api/analyze',
          tokensUsed: 0,
          responseTime: 0,
          status: 'rate-limited',
          model: 'llama-3.3-70b-versatile',
        })

        return Response.json(
          {
            translation: 'Groq API rate limit reached. Please wait a moment and try again.',
            isDemo: true,
            quotaExceeded: true,
            error: 'Groq rate limit exceeded',
          },
          { status: 200 }
        )
      }

      // Record failed usage metric
      groqManager.recordUsage({
        endpoint: '/api/analyze',
        tokensUsed: 0,
        responseTime: 0,
        status: 'error',
        model: 'llama-3.3-70b-versatile',
      })

      return Response.json(
        {
          translation: `Error: ${errorMessage}`,
          isDemo: true,
          quotaExceeded: false,
          error: errorMessage,
        },
        { status: 200 }
      )
    }
  } catch (error: any) {
    console.error('[v0] Error analyzing code:', error?.message || error)
    return Response.json(
      {
        translation: 'Error processing request',
        isDemo: true,
      },
      { status: 200 }
    )
  }
}
