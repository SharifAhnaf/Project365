import { groqManager } from '@/lib/groq-manager'

/**
 * Groq API Management Endpoint
 * Provides monitoring, analytics, and control over Groq API usage
 *
 * Available actions:
 * - status: Get current API health and status
 * - quota: Get quota information
 * - stats: Get usage statistics
 * - errors: Get recent error logs
 * - endpoints: Get metrics by endpoint
 * - reset: Clear metrics and logs
 * - config: Get or update configuration
 * - health: Detailed health check
 * - export: Export all analytics data
 */

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get('action') || 'status'

    switch (action) {
      case 'status':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getHealthStatus(),
        })

      case 'quota':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getQuotaInfo(),
        })

      case 'stats':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getUsageStats(),
        })

      case 'errors':
        const errorLimit = parseInt(searchParams.get('limit') || '10')
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getRecentErrors(errorLimit),
        })

      case 'endpoints':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getAllEndpointsUsage(),
        })

      case 'health':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getHealthStatus(),
          apiReady: groqManager.isAPIReady(),
          shouldRateLimit: groqManager.shouldRateLimit(),
        })

      case 'config':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.getConfig(),
        })

      case 'export':
        return Response.json({
          timestamp: new Date().toISOString(),
          data: groqManager.exportAnalytics(),
        })

      default:
        return Response.json(
          {
            error: `Unknown action: ${action}`,
            availableActions: [
              'status',
              'quota',
              'stats',
              'errors',
              'endpoints',
              'health',
              'config',
              'export',
            ],
          },
          { status: 400 }
        )
    }
  } catch (error: any) {
    return Response.json(
      {
        error: 'Failed to retrieve Groq admin data',
        details: error?.message,
      },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const action = body.action

    switch (action) {
      case 'reset':
        groqManager.resetMetrics()
        return Response.json({
          timestamp: new Date().toISOString(),
          message: 'Metrics and error logs cleared',
          data: groqManager.getHealthStatus(),
        })

      case 'update-config':
        const { config } = body
        if (!config) {
          return Response.json(
            { error: 'config field is required' },
            { status: 400 }
          )
        }
        groqManager.updateConfig(config)
        return Response.json({
          timestamp: new Date().toISOString(),
          message: 'Configuration updated',
          data: groqManager.getConfig(),
        })

      case 'record-usage':
        const { metric } = body
        if (!metric) {
          return Response.json(
            { error: 'metric field is required' },
            { status: 400 }
          )
        }
        groqManager.recordUsage(metric)
        return Response.json({
          timestamp: new Date().toISOString(),
          message: 'Usage recorded',
        })

      case 'record-error':
        const { endpoint, error, details } = body
        if (!endpoint || !error) {
          return Response.json(
            { error: 'endpoint and error fields are required' },
            { status: 400 }
          )
        }
        groqManager.recordError(endpoint, error, details)
        return Response.json({
          timestamp: new Date().toISOString(),
          message: 'Error recorded',
        })

      default:
        return Response.json(
          {
            error: `Unknown action: ${action}`,
            availableActions: [
              'reset',
              'update-config',
              'record-usage',
              'record-error',
            ],
          },
          { status: 400 }
        )
    }
  } catch (error: any) {
    return Response.json(
      {
        error: 'Failed to process Groq admin request',
        details: error?.message,
      },
      { status: 500 }
    )
  }
}
