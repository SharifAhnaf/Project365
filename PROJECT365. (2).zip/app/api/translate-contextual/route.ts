import { generateText } from 'ai'
import { createGroq } from '@ai-sdk/groq'
import { analyzeRateLimiter } from '@/lib/rate-limiter'
import { createCacheKey, getCachedResponse, setCachedResponse } from '@/lib/cache'
import { groqManager } from '@/lib/groq-manager'
import { splitCodeIntoChunks, shouldChunkCode, getChunkContext, combineChunkTranslations } from '@/lib/code-chunker'

// Initialize Groq client
const groq = createGroq({
  apiKey: process.env.GROQ_API_KEY,
})

type TranslationMode = 'plain-english'

const CHUNK_SIZE = 100 // lines per chunk
const CHUNK_THRESHOLD = 100 // lines before chunking is needed

const modePrompts: Record<TranslationMode, (code: string, fileName: string) => string> = {
  'plain-english': (code, fileName) => {
    const codeLines = code.split('\n').length
    return `You are the MapCode Translation Engine. Your job is to analyze code and explain it in plain English for non-technical stakeholders.

ANALYSIS APPROACH - LOGICAL BLOCKS:
Analyze the provided code and identify the main logical blocks (functions, classes, loops, or major sections). For each block:
1. Create a descriptive header (e.g., ## User Authentication Logic)
2. Provide a clear, high-level explanation of what that section does
3. Group related lines together in a paragraph
4. Explain the purpose and outcome of that block in plain English
5. Use markdown formatting with headers (##), bold text for variable names, and bullet points for steps

FORMATTING REQUIREMENTS:
- Use markdown syntax (##, **bold**, bullet points)
- Format variable names in **bold** (e.g., **userName**, **isValid**)
- Use clear section headers describing the logical block
- Write explanations as prose paragraphs, not line-by-line
- Group related functionality together
- Map clearly to code sections (e.g., 'In the first section...', 'Inside the main loop...')

DO NOT:
- Do NOT translate line-by-line
- Do NOT number individual lines
- Do NOT include "Line X:" prefixes
- Do NOT include line numbers in brackets
- Do NOT be overly technical
- Do NOT include "Part X" headers

File: ${fileName}
Total Code Lines: ${codeLines}

Code to Analyze:
\`\`\`
${code}
\`\`\`

ANALYSIS INSTRUCTIONS:
1. Scan the code and identify logical blocks (functions, classes, loops, conditional blocks)
2. For each block, create a descriptive markdown header
3. Write a clear explanation of what that block does and why it matters
4. Use **bold** for variable and function names
5. Use bullet points to list steps or key operations
6. Ensure output reads like a professional technical summary, not a line-by-line translation

Now analyze the code and provide logical block explanations:`
  }
}

export async function POST(request: Request) {
  let code = ''
  let fileName = ''
  let mode: TranslationMode = 'plain-english'

  try {
    const body = await request.json()
    code = body.code
    fileName = body.fileName
    mode = body.mode || 'plain-english'

    // Validate mode
    if (!modePrompts[mode as TranslationMode]) {
      return Response.json(
        { translation: 'Invalid translation mode', isDemo: true, error: 'Invalid mode' },
        { status: 400 }
      )
    }

    // Check if API key is available
    if (!process.env.GROQ_API_KEY) {
      return Response.json(
        {
          translation: 'Groq API key not configured. Please add GROQ_API_KEY to your environment variables.',
          isDemo: true,
          error: 'Missing API key',
        },
        { status: 200 }
      )
    }

    // Check cache first
    const cacheKey = createCacheKey(`analyze-${mode}`, code)
    const cachedResult = getCachedResponse(cacheKey)
    if (cachedResult) {
      console.log('[v0] Cache hit for contextual translation')
      return Response.json({ ...cachedResult, fromCache: true }, { status: 200 })
    }

    // Check rate limit
    if (analyzeRateLimiter(`translate:${mode}:${code.slice(0, 50)}`)) {
      console.log('[v0] Rate limit exceeded for translate endpoint')
      return Response.json(
        {
          translation: 'Too many requests. Please wait a moment before analyzing another file.',
          isDemo: true,
          rateLimited: true,
          error: 'Rate limit exceeded',
        },
        { status: 429 }
      )
    }

    try {
      const startTime = Date.now()
      
      // Check if code needs chunking
      const needsChunking = shouldChunkCode(code, CHUNK_THRESHOLD)
      let finalTranslation = ''
      let totalResponseTime = 0
      
      if (needsChunking) {
        // Process code in chunks
        const chunks = splitCodeIntoChunks(code, CHUNK_SIZE)
        const translations: string[] = []
        
        for (const chunk of chunks) {
          const chunkStartTime = Date.now()
          const chunkContext = getChunkContext(chunk, fileName)
          
          // Add chunk-specific instructions to help with context awareness
          const chunkPromptHeader = chunk.totalChunks > 1
            ? `\nNOTE: This is Part ${chunk.chunkIndex + 1} of ${chunk.totalChunks} (Lines ${chunk.startLine}-${chunk.endLine}). Maintain consistent terminology and style with other sections if this code file has multiple parts.\n`
            : ''
          
          const chunkPrompt = modePrompts[mode](chunk.content, chunkContext) + chunkPromptHeader
          
          const { text: chunkText } = await generateText({
            model: groq.chat('llama-3.3-70b-versatile'),
            prompt: chunkPrompt,
          })
          
          translations.push(chunkText)
          totalResponseTime += Date.now() - chunkStartTime
          console.log(`[v0] Processed chunk ${chunk.chunkIndex + 1}/${chunk.totalChunks} (${chunk.endLine - chunk.startLine + 1} lines)`)
        }
        
        // Combine all chunk translations with proper context
        finalTranslation = combineChunkTranslations(translations, chunks)
      } else {
        // Single request for small code
        const prompt = modePrompts[mode](code, fileName)
        const { text } = await generateText({
          model: groq.chat('llama-3.3-70b-versatile'),
          prompt,
        })
        finalTranslation = text
        totalResponseTime = Date.now() - startTime
      }
      
      // Record successful usage
      groqManager.recordUsage({
        endpoint: '/api/translate-contextual',
        tokensUsed: finalTranslation.length,
        responseTime: totalResponseTime,
        status: 'success',
        model: 'llama-3.3-70b-versatile',
        mode,
      })

      const result = { translation: finalTranslation, isDemo: false, quotaExceeded: false, mode, chunked: needsChunking }
      // Cache successful responses for 1 hour
      setCachedResponse(cacheKey, result, 3600000)

      return Response.json(result, { status: 200 })
    } catch (apiError: any) {
      const errorMessage = apiError?.message || JSON.stringify(apiError)
      console.error('[v0] Groq API Error:', errorMessage)

      // Record error usage
      groqManager.recordError('/api/translate-contextual', apiError, {
        mode,
        codeLength: code.length,
      })

      // Record failed usage metric
      groqManager.recordUsage({
        endpoint: '/api/translate-contextual',
        tokensUsed: 0,
        responseTime: 0,
        status: 'error',
        model: 'llama-3.3-70b-versatile',
        mode,
      })

      const isRateLimitError =
        errorMessage.includes('rate limit') ||
        errorMessage.includes('quota') ||
        apiError?.status === 429

      if (isRateLimitError) {
        // Record rate limit hit
        groqManager.recordUsage({
          endpoint: '/api/translate-contextual',
          tokensUsed: 0,
          responseTime: 0,
          status: 'rate-limited',
          model: 'llama-3.3-70b-versatile',
          mode,
        })

        return Response.json(
          {
            translation: 'Groq API rate limit reached. Please wait a moment and try again.',
            isDemo: true,
            quotaExceeded: true,
            error: 'Groq rate limit exceeded',
          },
          { status: 200 }
        )
      }

      return Response.json(
        {
          translation: `Error: ${errorMessage}`,
          isDemo: true,
          error: 'API Error',
        },
        { status: 200 }
      )
    }
  } catch (error: any) {
    console.error('[v0] Contextual translation error:', error)
    return Response.json(
      { translation: 'An error occurred during translation', isDemo: true, error: error?.message },
      { status: 200 }
    )
  }
}
