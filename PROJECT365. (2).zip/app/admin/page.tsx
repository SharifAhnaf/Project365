import { GroqAdminDashboard } from '@/components/groq-admin-dashboard'

export const metadata = {
  title: 'MapCode Admin - Groq API Management',
  description: 'Monitor and manage Groq API usage, quota, and performance',
}

export default function AdminPage() {
  return (
    <main className="min-h-screen bg-background">
      <GroqAdminDashboard />
    </main>
  )
}
